import bpy
from bpy.props import EnumProperty, BoolProperty, StringProperty
from bpy_extras.view3d_utils import region_2d_to_origin_3d, region_2d_to_vector_3d
from math import radians, degrees
from mathutils import Vector, Matrix, Quaternion
from mathutils.geometry import intersect_line_plane
from .. utils.object import parent, unparent
from .. utils.group import group, ungroup, get_group_matrix, select_group_children, get_child_depth, clean_up_groups, fade_group_sizes, get_group_hierarchy_down
from .. utils.collection import get_collection_depth
from .. utils.registration import get_prefs
from .. utils.modifier import get_mods_as_dict, add_mods_from_dict
from .. utils.object import compensate_children
from .. utils.draw import draw_point, draw_vector, draw_label, update_HUD_location
from .. utils.ui import init_cursor, init_status, finish_status
from .. utils.math import dynamic_format
from .. items import group_location_items, axis_items, axis_vector_mappings, ctrl
from .. colors import red, blue, green, yellow, white



class Group(bpy.types.Operator):
    bl_idname = "machin3.group"
    bl_label = "MACHIN3: Group"
    bl_description = "Group Objects by Parenting them to an Empty"
    bl_options = {'REGISTER', 'UNDO'}

    location: EnumProperty(name="Location", items=group_location_items, default='AVERAGE')
    rotation: EnumProperty(name="Rotation", items=group_location_items, default='WORLD')

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def draw(self, context):
        layout = self.layout

        column = layout.column()

        row = column.row()
        row.label(text="Location")
        row.prop(self, 'location', expand=True)

        row = column.row()
        row.label(text="Rotation")
        row.prop(self, 'rotation', expand=True)

    def invoke(self, context, event):
        self.coords = (event.mouse_region_x, event.mouse_region_y)

        return self.execute(context)

    def execute(self, context):
        sel = {obj for obj in context.selected_objects if (obj.parent and obj.parent.M3.is_group_empty) or not obj.parent}

        if sel:
            self.group(context, sel)

            return {'FINISHED'}
        return {'CANCELLED'}

    def group(self, context, sel):
        debug = False

        grouped = {obj for obj in sel if obj.parent and obj.parent.M3.is_group_empty}

        selected_empties = {obj for obj in sel if obj.M3.is_group_empty}

        if debug:
            print()
            print("               sel", [obj.name for obj in sel])
            print("           grouped", [obj.name for obj in grouped])
            print("  selected empties", [obj.name for obj in selected_empties])

        if grouped == sel:

            unselected_empties = {obj.parent for obj in sel if obj not in selected_empties and obj.parent and obj.parent.M3.is_group_empty and obj.parent not in selected_empties}

            top_level = {obj for obj in selected_empties | unselected_empties if obj.parent not in selected_empties | unselected_empties}

            if debug:
                print("unselected empties", [obj.name for obj in unselected_empties])
                print("         top level", [obj.name for obj in top_level])


            if len(top_level) == 1:
                new_parent = top_level.pop()

            else:
                parent_groups = {obj.parent for obj in top_level}

                if debug:
                    print("     parent_groups", [obj.name if obj else None for obj in parent_groups])

                new_parent = parent_groups.pop() if len(parent_groups) == 1 else None


        else:
            new_parent = None

        if debug:
            print("        new parent", new_parent.name if new_parent else None)
            print(20 * "-")


        ungrouped = {obj for obj in sel - grouped if obj not in selected_empties}

        top_level = {obj for obj in selected_empties if obj.parent not in selected_empties}

        grouped = {obj for obj in grouped if obj not in selected_empties and obj.parent not in selected_empties}

        if len(top_level) == 1 and new_parent in top_level:
            new_parent = list(top_level)[0].parent

            if debug:
                print("updated parent", new_parent.name)

        if debug:
            print("     top level", [obj.name for obj in top_level])
            print("       grouped", [obj.name for obj in grouped])
            print("     ungrouped", [obj.name for obj in ungrouped])

        for obj in top_level | grouped:
            unparent(obj)

        empty = group(context, top_level | grouped | ungrouped, location=self.location, rotation=self.rotation)

        if new_parent:
            parent(empty, new_parent)
            empty.M3.is_group_object = True


        clean_up_groups(context)

        if get_prefs().group_fade_sizes:
            fade_group_sizes(context, init=True)

        bpy.ops.machin3.draw_label(text=f"{'Sub' if new_parent else 'Root'}: {empty.name}", coords=self.coords, color=(0.5, 1, 0.5) if new_parent else (1, 1, 1), time=get_prefs().HUD_fade_group, alpha=0.75)


class UnGroup(bpy.types.Operator):
    bl_idname = "machin3.ungroup"
    bl_label = "MACHIN3: Un-Group"
    bl_options = {'REGISTER', 'UNDO'}

    ungroup_all_selected: BoolProperty(name="Un-Group all Selected Groups", default=False)
    ungroup_entire_hierarchy: BoolProperty(name="Un-Group entire Hierarchy down", default=False)

    @classmethod
    def description(cls, context, properties):
        if context.scene.M3.group_recursive_select and context.scene.M3.group_select:
            return "Un-Group selected top-level Groups\nALT: Un-Group all selected Groups"
        else:
            return "Un-Group selected top-level Groups\nALT: Un-Group all selected Groups\nCTRL: Un-Group entire Hierarchy down"

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def draw(self, context):
        layout = self.layout

        column = layout.column()

        row = column.row(align=True)
        row.label(text="Un-Group")
        row.prop(self, 'ungroup_all_selected', text='All Selected', toggle=True)
        row.prop(self, 'ungroup_entire_hierarchy', text='Entire Hierarchy', toggle=True)

    def invoke(self, context, event):
        self.ungroup_all_selected = event.alt
        self.ungroup_entire_hierarchy = event.ctrl

        return self.execute(context)

    def execute(self, context):
        empties, all_empties = self.get_group_empties(context)

        if empties:
            self.ungroup(empties, all_empties)

            clean_up_groups(context)

            if get_prefs().group_fade_sizes:
                fade_group_sizes(context, init=True)

            return {'FINISHED'}
        return {'CANCELLED'}

    def get_group_empties(self, context):
        all_empties = [obj for obj in context.selected_objects if obj.M3.is_group_empty]

        if self.ungroup_all_selected:
            empties = all_empties
        else:
            empties = [e for e in all_empties if e.parent not in all_empties]

        return empties, all_empties

    def collect_entire_hierarchy(self, empties):
        for e in empties:
            children = [obj for obj in e.children if obj.M3.is_group_empty]

            for c in children:
                self.empties.append(c)
                self.collect_entire_hierarchy([c])

    def ungroup(self, empties, all_empties):
        if self.ungroup_entire_hierarchy:
            self.empties = empties
            self.collect_entire_hierarchy(empties)
            empties = set(self.empties)

        for empty in empties:
            ungroup(empty)


class Groupify(bpy.types.Operator):
    bl_idname = "machin3.groupify"
    bl_label = "MACHIN3: Groupify"
    bl_description = "Turn any Empty Hirearchy into Group"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        if context.mode == 'OBJECT':
            return [obj for obj in context.selected_objects if obj.type == 'EMPTY' and not obj.M3.is_group_empty and obj.children]

    def execute(self, context):
        all_empties = [obj for obj in context.selected_objects if obj.type == 'EMPTY' and not obj.M3.is_group_empty and obj.children]

        empties = [e for e in all_empties if e.parent not in all_empties]

        self.groupify(empties)

        if get_prefs().group_fade_sizes:
            fade_group_sizes(context, init=True)

        return {'FINISHED'}

    def groupify(self, objects):
        for obj in objects:
            if obj.type == 'EMPTY' and not obj.M3.is_group_empty and obj.children:
                obj.M3.is_group_empty = True
                obj.M3.is_group_object = True if obj.parent and obj.parent.M3.is_group_empty else False
                obj.show_in_front = True
                obj.empty_display_type = 'CUBE'
                obj.empty_display_size = get_prefs().group_size
                obj.show_name = True

                if not any([s in obj.name.lower() for s in ['grp', 'group']]):
                    obj.name = f"{obj.name}_GROUP"

                self.groupify(obj.children)

            else:
                obj.M3.is_group_object = True



class Select(bpy.types.Operator):
    bl_idname = "machin3.select_group"
    bl_label = "MACHIN3: Select Group"
    bl_description = "Select Group\nCTRL: Select entire Group Hierarchy down"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def description(cls, context, properties):
        if context.scene.M3.group_recursive_select:
            return "Select entire Group Hierarchies down"
        else:
            return "Select Top Level Groups\nCTRL: Select entire Group Hierarchy down"

    @classmethod
    def poll(cls, context):
        if context.mode == 'OBJECT':
            return [obj for obj in context.selected_objects if obj.M3.is_group_empty or obj.M3.is_group_object]

    def invoke(self, context, event):
        clean_up_groups(context)

        empties = {obj for obj in context.selected_objects if obj.M3.is_group_empty}
        objects = [obj for obj in context.selected_objects if obj.M3.is_group_object and obj not in empties]

        for obj in objects:
            if obj.parent and obj.parent.M3.is_group_empty:
                empties.add(obj.parent)


        for e in empties:
            if e.visible_get():
                e.select_set(True)

                if len(empties) == 1:
                    context.view_layer.objects.active = e

            select_group_children(context.view_layer, e, recursive=event.ctrl or context.scene.M3.group_recursive_select)

        if get_prefs().group_fade_sizes:
            fade_group_sizes(context, init=True)

        return {'FINISHED'}


class Duplicate(bpy.types.Operator):
    bl_idname = "machin3.duplicate_group"
    bl_label = "MACHIN3: duplicate_group"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def description(cls, context, properties):
        if context.scene.M3.group_recursive_select:
            return "Duplicate entire Group Hierarchies down\nALT: Create Instances"
        else:
            return "Duplicate Top Level Groups\nALT: Create Instances\nCTRL: Duplicate entire Group Hierarchies down"

    @classmethod
    def poll(cls, context):
        if context.mode == 'OBJECT':
            return [obj for obj in context.selected_objects if obj.M3.is_group_empty]

    def invoke(self, context, event):
        empties = [obj for obj in context.selected_objects if obj.M3.is_group_empty]

        bpy.ops.object.select_all(action='DESELECT')

        for e in empties:
            e.select_set(True)
            select_group_children(context.view_layer, e, recursive=event.ctrl or context.scene.M3.group_recursive_select)

        if get_prefs().group_fade_sizes:
            fade_group_sizes(context, init=True)

        bpy.ops.object.duplicate_move_linked('INVOKE_DEFAULT') if event.alt else bpy.ops.object.duplicate_move('INVOKE_DEFAULT')

        return {'FINISHED'}



class Add(bpy.types.Operator):
    bl_idname = "machin3.add_to_group"
    bl_label = "MACHIN3: Add to Group"
    bl_description = "Add Selection to Group"
    bl_options = {'REGISTER', 'UNDO'}

    realign_group_empty: BoolProperty(name="Re-Align Group Empty", default=False)
    location: EnumProperty(name="Location", items=group_location_items, default='AVERAGE')
    rotation: EnumProperty(name="Rotation", items=group_location_items, default='WORLD')

    add_mirror: BoolProperty(name="Add Mirror Modifiers, if there are common ones among the existing Group's objects, that are missing from the new Objects", default=True)
    is_mirror: BoolProperty()

    add_color: BoolProperty(name="Add Object Color, from Group's Empty", default=True)
    is_color: BoolProperty()

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def draw(self, context):
        layout = self.layout

        column = layout.column()

        column.prop(self, 'realign_group_empty', toggle=True)

        row = column.row()
        row.active = self.realign_group_empty
        row.prop(self, 'location', expand=True)

        row = column.row()
        row.active = self.realign_group_empty
        row.prop(self, 'rotation', expand=True)

        row = column.row(align=True)

        if self.is_color:
            row.prop(self, 'add_color', text="Add Color", toggle=True)

        if self.is_mirror:
            row.prop(self, 'add_mirror', text="Add Mirror", toggle=True)

    def execute(self, context):
        debug = False

        active_group = context.active_object if context.active_object and context.active_object.M3.is_group_empty and context.active_object.select_get() else None

        if not active_group:

            active_group = context.active_object.parent if context.active_object and context.active_object.M3.is_group_object and context.active_object.select_get() else None

            if not active_group:
                return {'CANCELLED'}

        objects = [obj for obj in context.selected_objects if obj != active_group and obj not in active_group.children and (not obj.parent or (obj.parent and obj.parent.M3.is_group_empty and not obj.parent.select_get()))]

        if debug:
            print("active group", active_group.name)
            print("     addable", [obj.name for obj in objects])

        if objects:

            children = [c for c in active_group.children if c.M3.is_group_object and c.type == 'MESH' and c.name in context.view_layer.objects]

            self.is_mirror = any(obj for obj in children for mod in obj.modifiers if mod.type == 'MIRROR')

            self.is_color = any(obj.type == 'MESH' for obj in objects)

            for obj in objects:
                if obj.parent:
                    unparent(obj)

                parent(obj, active_group)

                obj.M3.is_group_object = True

                if obj.type == 'MESH':

                    if children and self.add_mirror:
                        self.mirror(obj, active_group, children)

                    if self.add_color:
                        obj.color = active_group.color

            if self.realign_group_empty:

                gmx = get_group_matrix(context, [c for c in active_group.children], self.location, self.rotation)

                compensate_children(active_group, active_group.matrix_world, gmx)

                active_group.matrix_world = gmx


            clean_up_groups(context)

            if get_prefs().group_fade_sizes:
                fade_group_sizes(context, init=True)

            return {'FINISHED'}
        return {'CANCELLED'}

    def mirror(self, obj, active_group, children):

        all_mirrors = {}

        for c in children:
            if c.M3.is_group_object and not c.M3.is_group_empty and c.type == 'MESH':
                mirrors = get_mods_as_dict(c, types=['MIRROR'], skip_show_expanded=True)

                if mirrors:
                    all_mirrors[c] = mirrors

        if all_mirrors and len(all_mirrors) == len(children):


            obj_props = [props for props in get_mods_as_dict(obj, types=['MIRROR'], skip_show_expanded=True).values()]

            if len(all_mirrors) == 1:

                common_props = [props for props in next(iter(all_mirrors.values())).values() if props not in obj_props]

            else:
                common_props = []

                for c, mirrors in all_mirrors.items():
                    others = [obj for obj in all_mirrors if obj != c]

                    for name, props in mirrors.items():
                        if all(props in all_mirrors[o].values() for o in others) and props not in common_props:
                            if props not in obj_props:
                                common_props.append(props)


            if common_props:
                common_mirrors = {f"Mirror{'.' + str(idx).zfill(3) if idx else ''}": props for idx, props in enumerate(common_props)}

                add_mods_from_dict(obj, common_mirrors)


class Remove(bpy.types.Operator):
    bl_idname = "machin3.remove_from_group"
    bl_label = "MACHIN3: Remove from Group"
    bl_description = "Remove Selection from Group"
    bl_options = {'REGISTER', 'UNDO'}

    realign_group_empty: BoolProperty(name="Re-Align Group Empty", default=False)
    location: EnumProperty(name="Location", items=group_location_items, default='AVERAGE')
    rotation: EnumProperty(name="Rotation", items=group_location_items, default='WORLD')

    @classmethod
    def poll(cls, context):
        if context.mode == 'OBJECT':
            return True

    def draw(self, context):
        layout = self.layout

        column = layout.column()

        column.prop(self, 'realign_group_empty', toggle=True)

        row = column.row()
        row.active = self.realign_group_empty
        row.prop(self, 'location', expand=True)

        row = column.row()
        row.active = self.realign_group_empty
        row.prop(self, 'rotation', expand=True)

    def execute(self, context):
        debug = False

        all_group_objects = [obj for obj in context.selected_objects if obj.M3.is_group_object]

        group_objects = [obj for obj in all_group_objects if obj.parent not in all_group_objects]

        if debug:
            print()
            print("all group objects", [obj.name for obj in all_group_objects])
            print("    group objects", [obj.name for obj in group_objects])

        if group_objects:

            empties = set()

            for obj in group_objects:
                empties.add(obj.parent)

                unparent(obj)
                obj.M3.is_group_object = False

            if self.realign_group_empty:
                for e in empties:
                    children = [c for c in e.children]

                    if children:
                        gmx = get_group_matrix(context, children, self.location, self.rotation)

                        compensate_children(e, e.matrix_world, gmx)

                        e.matrix_world = gmx

            clean_up_groups(context)

            return {'FINISHED'}
        return {'CANCELLED'}



class ToggleChildren(bpy.types.Operator):
    bl_idname = "machin3.toggle_outliner_children"
    bl_label = "MACHIN3: Toggle Outliner Children"
    bl_description = ""
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.area.type == 'OUTLINER'

    def execute(self, context):
        area = context.area
        space = area.spaces[0]

        space.use_filter_children = not space.use_filter_children

        return {'FINISHED'}


class ToggleGroupMode(bpy.types.Operator):
    bl_idname = "machin3.toggle_outliner_group_mode"
    bl_label = "MACHIN3: Toggle Outliner Group Mode"
    bl_description = ""
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.area.type == 'OUTLINER'

    def execute(self, context):
        area = context.area
        space = area.spaces[0]

        if space.use_filter_object_mesh:
            space.use_filter_collection = False
            space.use_filter_object_mesh = False
            space.use_filter_object_content = False
            space.use_filter_object_armature = False
            space.use_filter_object_light = False
            space.use_filter_object_camera = False
            space.use_filter_object_others = False
            space.use_filter_children = True

        else:
            space.use_filter_collection = True
            space.use_filter_object_mesh = True
            space.use_filter_object_content = True
            space.use_filter_object_armature = True
            space.use_filter_object_light = True
            space.use_filter_object_camera = True
            space.use_filter_object_others = True

        return {'FINISHED'}


class CollapseOutliner(bpy.types.Operator):
    bl_idname = "machin3.collapse_outliner"
    bl_label = "MACHIN3: Collapse Outliner"
    bl_description = ""
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.area.type == 'OUTLINER'

    def execute(self, context):

        col_depth = get_collection_depth(self, [context.scene.collection], init=True)

        child_depth = get_child_depth(self, [obj for obj in context.scene.objects if obj.children], init=True)

        for i in range(max(col_depth, child_depth) + 1):
            bpy.ops.outliner.show_one_level(open=False)

        return {'FINISHED'}


class ExpandOutliner(bpy.types.Operator):
    bl_idname = "machin3.expand_outliner"
    bl_label = "MACHIN3: Expand Outliner"
    bl_description = ""
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.area.type == 'OUTLINER'

    def execute(self, context):

        bpy.ops.outliner.show_hierarchy()

        depth = get_collection_depth(self, [context.scene.collection], init=True)

        for i in range(depth):
            bpy.ops.outliner.show_one_level(open=True)

        return {'FINISHED'}




def draw_transform_group(op):
    def draw(self, context):
        layout = self.layout

        row = layout.row(align=True)

        row.label(text="Transform Group")

        row.label(text="", icon='MOUSE_LMB')
        row.label(text="Finish")

        row.label(text="", icon='MOUSE_RMB')
        row.label(text="Cancel")

        row.separator(factor=10)

        row.label(text="", icon='EVENT_CTRL')
        row.label(text="5° Angle Snap")
        row.separator(factor=1)

        row.label(text="", icon='MOUSE_MMB')
        row.label(text="Scale Gizmo")
        row.separator(factor=1)

        row.label(text="", icon='EVENT_S')
        row.label(text=f"Set Rest Pose + Finish")
        row.separator(factor=1)

        row.label(text="", icon='EVENT_R')
        row.label(text=f"Recall Rest Pose + Finish")

    return draw


class Transform(bpy.types.Operator):
    bl_idname = "machin3.transform_group"
    bl_label = "MACHIN3: Transform Group"
    bl_options = {'REGISTER', 'UNDO'}

    name: StringProperty(name="Group Empty Name")
    axis: EnumProperty(name="Rotation Axis", items=axis_items, default='X')

    @classmethod
    def description(cls, context, properties):
        return f"Rotate Group '{properties.name}' around its {properties.axis} Axis"

    def draw_HUD(self, args):
        context, event = args

        angle = dynamic_format(self.HUD_angle, decimal_offset=0 if self.is_angle_snapping else 2)
        color = yellow if self.is_angle_snapping else white
        title = f"{angle}° {'Snapping' if self.is_angle_snapping else ''}"
        draw_label(context, title=title, coords=Vector((self.HUD_x, self.HUD_y)), center=False, color=color, alpha=1)

    def modal(self, context, event):
        context.area.tag_redraw()

        if event.type == 'MOUSEMOVE':
            self.mousepos = Vector((event.mouse_region_x, event.mouse_region_y))
            update_HUD_location(self, event, offsetx=10, offsety=10)

        self.is_angle_snapping = event.ctrl

        events = ['MOUSEMOVE', 'S', 'R', *ctrl, 'WHEELUPMOUSE', 'WHEELDOWNMOUSE']

        if event.type in events:

            if event.type in ['MOUSEMOVE', *ctrl]:

                rotation = self.get_rotation(context)

                self.empty.matrix_world = Matrix.LocRotScale(self.init_location, rotation, self.init_scale)

            elif event.type in ['WHEELUPMOUSE', 'WHEELDOWNMOUSE']:

                if event.type == 'WHEELUPMOUSE':
                    self.empty.M3.group_gizmo_size += 0.1

                else:
                    self.empty.M3.group_gizmo_size -= 0.1

                self.gzm.scale_basis = context.scene.M3.group_gizmo_size * self.empty.M3.group_size * self.empty.M3.group_gizmo_size * 5

            elif event.type in ['S', 'R']:

                if event.type == 'S' and event.value == 'PRESS':
                    self.finish()

                    self.empty.M3.group_rest_pose = self.empty.matrix_basis

                    location = self.empty.matrix_world.to_translation()
                    bpy.ops.machin3.draw_group_rest_pose(location=location, size=self.gzm.scale_basis, time=0.1, steps=0.01, alpha=0.2, reverse=False)

                    self.is_setting_rest_pose = True

                    return {'FINISHED'}

                elif event.type == 'R' and event.value == 'PRESS':
                    self.finish()

                    loc, _, sca = self.empty.matrix_basis.decompose()
                    rot = self.empty.M3.group_rest_pose.to_quaternion()
                    self.empty.matrix_basis = Matrix.LocRotScale(loc, rot, sca)

                    location = self.empty.matrix_world.to_translation()
                    bpy.ops.machin3.draw_group_rest_pose(location=location, size=self.gzm.scale_basis, time=0.1, steps=0.01, alpha=0.2, reverse=True)

                    self.is_recalling_rest_pose = True

                    return {'FINISHED'}


        elif event.type in {'LEFTMOUSE', 'SPACE'}:
            self.finish()
            return {'FINISHED'}

        elif event.type in {'RIGHTMOUSE', 'ESC'}:
            self.empty.matrix_world = Matrix.LocRotScale(self.init_location, self.init_rotation, self.init_scale)

            self.finish()
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}

    def finish(self):
        bpy.types.SpaceView3D.draw_handler_remove(self.HUD, 'WINDOW')

        finish_status(self)

    def invoke(self, context, event):

        self.gzm_grp = context.gizmo_group

        self.empty = bpy.data.objects.get(self.name)


        if self.empty and self.gzm_grp:

            self.mousepos = Vector((event.mouse_region_x, event.mouse_region_y))
            self.HUD_angle = 0

            self.empty_dir = None

            self.axis_direction = axis_vector_mappings[self.axis]
            self.init_rotation_intersect = None
            self.init_location, self.init_rotation, self.init_scale = self.empty.matrix_world.decompose()

            self.is_angle_snapping = True

            self.is_setting_rest_pose = False
            self.is_recalling_rest_pose = False

            self.gzm, self.others = self.get_gizmos(self.gzm_grp)


            init_status(self, context, func=draw_transform_group(self))


            init_cursor(self, event)

            args = (context, event)
            self.HUD = bpy.types.SpaceView3D.draw_handler_add(self.draw_HUD, (args, ), 'WINDOW', 'POST_PIXEL')

            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}

        return {'CANCELLED'}

    def get_gizmos(self, gzm_group):

        active_gzm = None
        other_gizmos = []

        if gzm_group:
            for gzm in gzm_group.gizmos:
                if gzm.is_modal:
                    active_gzm = gzm

                else:
                    other_gizmos.append(gzm)

        return active_gzm, other_gizmos

    def get_rotation(self, context):
        mx = self.empty.matrix_world

        self.view_origin = region_2d_to_origin_3d(context.region, context.region_data, self.mousepos)
        self.view_dir = region_2d_to_vector_3d(context.region, context.region_data, self.mousepos)


        self.empty_origin = mx.to_translation()

        if self.empty_dir is None:
            self.empty_dir = (mx.to_quaternion() @ self.axis_direction)


        i = intersect_line_plane(self.view_origin, self.view_origin + self.view_dir, self.empty_origin, self.empty_dir)

        if i:

            if not self.init_rotation_intersect:
                self.init_rotation_intersect = i
                return self.init_rotation

            else:
                v1 = self.init_rotation_intersect - self.empty_origin
                v2 = i - self.empty_origin

                deltarot = v1.rotation_difference(v2).normalized()

                angle = v1.angle(v2)

                if self.is_angle_snapping:
                    step = 5

                    dangle = degrees(angle)
                    mod = dangle % step

                    angle = radians(dangle + (step - mod)) if mod >= (step / 2) else radians(dangle - mod)


                    deltarot = Quaternion(deltarot.axis, angle)

                rotation = (deltarot @ self.init_rotation).normalized()

                dot = self.empty_dir.dot(deltarot.axis)

                self.HUD_angle = -dot * degrees(angle)

                return rotation
            return self.init_rotation


class RestPose(bpy.types.Operator):
    bl_idname = "machin3.group_rest_pose"
    bl_label = "MACHIN3: Group Rest Pose"
    bl_options = {'REGISTER', 'UNDO'}

    mode: EnumProperty(name="Rest Pose Mode", items=[('SET', 'Set', ''), ('RECALL', 'Recall', '')], default='RECALL')
    name: StringProperty(name="Group Name")

    recursive = False

    @classmethod
    def description(cls, context, properties):
        if properties.name:
            return f"{properties.mode.capitalize()} Group's Rest Pose\nALT: {properties.mode.capitalize()} it recursively down the Group Hierarchy"
        else:
            return f"{properties.mode.capitalize()} All Group Rest Poses"

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def invoke(self, context, event):
        self.recursive = event.alt
        return self.execute(context)

    def execute(self, context):

        if self.name:
            empty = bpy.data.objects.get(self.name)

            if empty and empty.M3.is_group_empty and empty.M3.show_group_gizmo:

                self.set_or_recall_rest_pose(empty, mode=self.mode)

                if self.recursive:

                    empties = []
                    get_group_hierarchy_down(empty, empties)

                    for e in [e for e in empties if e.M3.show_group_gizmo]:

                        self.set_or_recall_rest_pose(e, mode=self.mode)

                return {'FINISHED'}

        else:

            empties = [obj for obj in context.visible_objects if obj.M3.is_group_empty and obj.M3.show_group_gizmo]

            for e in empties:
                self.set_or_recall_rest_pose(e, mode=self.mode)

            return {'FINISHED'}
        return {'CANCELLED'}

    def set_or_recall_rest_pose(self, empty, mode):
        if mode == 'SET':
            empty.M3.group_rest_pose = empty.matrix_basis

        else:
            loc, _, sca = empty.matrix_basis.decompose()
            rot = empty.M3.group_rest_pose.to_quaternion()
            empty.matrix_basis = Matrix.LocRotScale(loc, rot, sca)


class BakeGroupGizmoSize(bpy.types.Operator):
    bl_idname = "machin3.bake_group_gizmo_size"
    bl_label = "MACHIN3: Bake Group Gizmo Size"
    bl_description = ""
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.scene.M3.group_gizmo_size != 1

    def execute(self, context):
        gizmo_size = context.scene.M3.group_gizmo_size
        divider = 1 / gizmo_size

        group_empties = [obj for obj in bpy.data.objects if obj.type == 'EMPTY' and obj.M3.is_group_empty]

        for obj in group_empties:
            obj.M3.group_gizmo_size /= divider

        context.scene.M3.group_gizmo_size = 1
        return {'FINISHED'}
