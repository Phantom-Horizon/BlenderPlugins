HOW TO INSTALL:

Use the install button on the zip folder in user preferences > add-ons. If you have the add-on 
before the folder structure, uninstall that first then close and re-open Blender to install the new 
one.

SUPPORTED VERSIONS:

These add-ons are always ported towards the official version only. Nightly builds and backward 
compatibility are no longer supported since I'm basically undermanned to manage all that work.

Download the official build here: https://blender.org/

CONTACTS:

https://facebook.com/blenderguppy
https://instagram.com/blenderguppy
https://twitter.com/blenderguppy

Hang out with me on discord. Please join the channel so you can interact with me much easier.
Discord: https://discord.gg/GUftHR3xYF

Use this social media sites to contact me just in case the store emails does not reach me.

RESOURCES:

Follow me in https://youtube.com/ianlloyddelacruz where you can find demos and tutorials for the 
add-ons. Demo videos are updated regularly so be sure to subscribe and follow.

Check out my Patreon in https://patreon.com/blenderguppy for random free stuffs using the add-ons.