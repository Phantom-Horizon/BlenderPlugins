# -*- coding: UTF-8 -*-

bl_info = {
    'name': 'KIT OPS Pro',
    'author': 'Chipp Walters, iBlender@taobao.com, MX2, proxe, bonjorno7, Mark Kingsnorth',
    'version': (2, 20, 53),
    'blender': (2, 83, 0),
    'location': 'View3D > Toolshelf (T)',
    'description': 'Streamlined kit bash library with additional productivity tools',
    'doc_url': 'http://cw1.me/kops2docs',
    'category': '3D View',
    "tracker_url": "https://item.taobao.com/item.htm?ft=t&id=631624469185"}

import bpy

from . addon import preference, property
from . addon.interface import operator, panel
from . addon.utility import handler, previews


def register():
    previews.register()

    preference.register()
    property.register()

    operator.register()
    panel.register()

    handler.register()


def unregister():
    handler.unregister()

    panel.unregister()
    operator.unregister()

    property.unregister()
    preference.unregister()

    previews.unregister()
