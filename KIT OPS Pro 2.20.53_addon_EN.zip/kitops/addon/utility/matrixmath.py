import os

import bpy

from bpy.types import Operator
from bpy.props import *
from bpy.utils import register_class, unregister_class

from . import addon, bbox, id, insert, modifier, remove, constants, previews, update as kitops_update, listeners, math, persistence

from mathutils import Vector, Euler, Matrix
from math import radians

import mathutils

def authoring_save_pre():
    option = addon.option()

    thumbnail_scene = None
    for scene in bpy.data.scenes:
        if scene.kitops.thumbnail:
            thumbnail_scene = scene

            for obj in thumbnail_scene.collection.all_objects:
                exists = False
                for scn in bpy.data.scenes:
                    if scn == scene:
                        continue

                    if obj.name in scn.collection.all_objects:
                        exists = True
                        continue

                if not exists:
                    obj.kitops.temp = True

            break

    if not thumbnail_scene and bpy.data.filepath != addon.path.thumbnail():
        persistence.remove_temp_objects()

    if insert.authoring() and bpy.data.filepath != addon.path.thumbnail():
        for mat in bpy.data.materials:
            mat.kitops.id = id.uuid()

        try: bpy.ops.object.mode_set(mode='OBJECT')
        except: pass

        for obj in bpy.context.visible_objects:
            obj.kitops.inserted = False

        main = False
        for obj in bpy.data.objects:
            obj.kitops.id = ''
            obj.kitops.author = option.author
            obj.kitops.insert = False
            obj.kitops.applied = False
            obj.kitops.animated = bpy.context.scene.kitops.animated
            obj.kitops.hide = obj not in bpy.context.visible_objects[:]
            obj.kitops['insert_target'] = None
            obj.kitops['mirror_target'] = None
            obj.kitops['reserved_target'] = None
            obj.kitops['main_object'] = None

            if obj.kitops.main:
                main = True

            if obj.data:
                obj.data.kitops.id = id.uuid()
                obj.data.kitops.insert = False

        if main:
            main = [obj for obj in bpy.data.objects if obj.kitops.main][0]

        else:
            bpy.data.objects[0].kitops.main = True
            main = bpy.data.objects[0]

        bpy.context.view_layer.objects.active = main
        main.select_set(True)

        if bpy.context.scene.kitops.auto_parent:
            # bpy.ops.object.visual_transform_apply()

            for obj in bpy.data.objects:
                obj['parent'] = None

            for obj in bpy.data.objects:
                obj.select_set(True)

            try: bpy.ops.object.parent_set(type='OBJECT', keep_transform=True)
            except: pass

    elif not insert.authoring():
        for obj in bpy.data.objects:
            if obj.kitops.insert:
                continue

            obj.kitops['insert_target'] = None
            obj.kitops['mirror_target'] = None
            obj.kitops['reserved_target'] = None
            obj.kitops['main_object'] = None


def authoring_load_post():
    option = addon.option()

    scene_objects = bpy.context.scene.collection.all_objects[:]
    for obj in bpy.data.objects:
        if obj not in scene_objects:
            remove_object(obj)

    main = False
    for obj in bpy.data.objects:
        if obj.kitops.main:
            bpy.context.view_layer.objects.active = obj
            main = True
            break

    if not main:
        if bpy.context.active_object:
            bpy.context.active_object.kitops.main = True
        elif len(bpy.data.objects):
            bpy.context.view_layer.objects.active = bpy.data.objects[0]
            bpy.data.objects[0].kitops['main'] = True

    author = False
    for obj in bpy.data.objects:
        if obj.kitops.author and obj.kitops.author != 'Your Name':
            author = obj.kitops.author
            break

    if author:
        option.author = author

    else:
        option.author = addon.preference().author
        for obj in bpy.data.objects:
            obj.kitops.author = addon.preference().author

def authoring_depsgraph_update_post():
    if len(bpy.data.objects) == 1:
        bpy.data.objects[0].kitops['main'] = True

    for obj in bpy.data.objects:
        if obj.type not in {'MESH', 'CURVE', 'SURFACE', 'META', 'FONT', 'ARMATURE'} and obj.kitops.type != 'WIRE':
            obj.kitops.type = 'WIRE'
        if obj.type != 'MESH' and obj.kitops.type == 'CUTTER' and obj.kitops.type != 'WIRE':
            obj.kitops.type = 'WIRE'
        if obj.kitops.main and obj.kitops.selection_ignore:
            obj.kitops.selection_ignore = False

    if hasattr(bpy, 'context') and bpy.context.scene and bpy.context.scene.kitops.factory:
        for obj in bpy.context.scene.collection.all_objects:
            if not obj.kitops.ground_box:
                continue

            for mod in obj.modifiers:
                if mod.type == 'BOOLEAN' and mod.object:
                    if mod.object.kitops.boolean_type != mod.operation and obj.kitops.boolean_type != 'INSERT' and mod.object.kitops.boolean_type != 'INSERT':
                        mod.operation = mod.object.kitops.boolean_type

class KO_OT_edit_insert_confirm(Operator):
    bl_idname = 'ko.edit_insert_confirm'
    bl_label = 'Lose unsaved changes?'
    bl_description = 'Edit the active KITOPS INSERT'

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        return KO_OT_edit_insert.execute(self, context)


class KO_OT_edit_insert(Operator):
    bl_idname = 'ko.edit_insert'
    bl_label = 'Edit INSERT'
    bl_description = 'Edit the active KITOPS INSERT'

    def invoke(self, context, event):
        if bpy.data.is_dirty:
            return bpy.ops.ko.edit_insert_confirm('INVOKE_DEFAULT')
        return self.execute(context)

    def execute(self, context):
        option = context.window_manager.kitops
        path = option.kpack.categories[option.kpack.active_index].blends[option.kpack.categories[option.kpack.active_index].active_index].location
        bpy.ops.wm.open_mainfile(filepath=path)

        return {'FINISHED'}


class create_insert():
    bl_options = {'INTERNAL'}

    duplicate: BoolProperty(default=False)
    material: BoolProperty(default=False)
    children: BoolProperty(default=True)

    @classmethod
    def poll(cls, context):
        return context.active_object and context.selected_objects and bpy.data.filepath

    def invoke(self, context, event):

        bpy.ops.wm.save_mainfile(filepath=bpy.data.filepath)

        if not bpy.data.use_autopack:
            bpy.ops.file.autopack_toggle()

        bpy.ops.object.mode_set(mode='OBJECT')

        if not self.duplicate and not self.material:
            self.duplicate = not event.ctrl

        persistence.new_factory_scene(context, link_selected=not self.material, link_children=self.children, duplicate=self.duplicate and not self.material, material_base=self.material)

        bpy.ops.view3d.camera_to_view_selected()

        return {'FINISHED'}


class KO_OT_create_insert(Operator, create_insert):
    bl_idname = 'ko.create_insert'
    bl_label = 'Create INSERT'
    bl_description = ('Create INSERT.\n\n'
                      '  Ctrl - Link selected objects')


class KO_OT_create_insert_material(Operator, create_insert):
    bl_idname = 'ko.create_insert_material'
    bl_label = 'Create Material INSERT'
    bl_description = 'Create new material and thumbnail from active object\'s active material'

    @classmethod
    def poll(cls, context):
        return create_insert.poll(context) and context.active_object.active_material and bpy.data.filepath



def save_file(context, path=''):
    versions = context.preferences.filepaths.save_version
    context.preferences.filepaths.save_version = 0

    try:
        bpy.ops.wm.save_mainfile(filepath=os.path.realpath(path) if path else bpy.data.filepath)
        bpy.ops.wm.save_mainfile()
    except: print(f'KITOPS: Save file exception{(" @" + path) if path else ""}')

    context.preferences.filepaths.save_version = versions




class KO_OT_save_as_insert(Operator):
    bl_idname = 'ko.save_as_insert'
    bl_label = 'Save INSERT'
    bl_description = 'Save the INSERT'
    bl_options = {'INTERNAL'}

    hide_props_region: BoolProperty(default=True, options={'HIDDEN'})
    filter_folder: BoolProperty(default=True, options={'HIDDEN'})
    filter_blender: BoolProperty(default=True, options={'HIDDEN'})
    check_existing: BoolProperty(default=True, options={'HIDDEN'})

    filepath: StringProperty(
        name = 'File Path',
        description = 'File path used for saving INSERT\'s',
        maxlen = 1024,
        subtype = 'FILE_PATH')

    def check(self, conext):
        filepath = self.filepath

        if os.path.basename(filepath):
            filepath = bpy.path.ensure_ext(filepath, '.blend')

            if filepath != self.filepath:
                self.filepath = filepath

        return filepath

    def invoke(self, context, event):
        if not self.filepath:
            self.filepath = persistence.insert_path(context.window_manager.kitops.insert_name, context)

        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        persistence.save_insert(path=self.filepath)
        return {'FINISHED'}


class KO_OT_save_insert(Operator):
    bl_idname = 'ko.save_insert'
    bl_label = 'Save INSERT'
    bl_description = 'Save the INSERT'
    bl_options = {'INTERNAL'}

    @classmethod
    def poll(cls, context):
        return context.window_manager.kitops.insert_name

    def invoke(self, context, event):
        local_factory = not context.scene.kitops.factory

        if local_factory:
            save_file(context)
            bpy.ops.wm.open_mainfile(filepath=bpy.data.filepath, load_ui=True)

            self.report({'INFO'}, F'Saved Insert: {bpy.data.filepath}')
            return {'FINISHED'}

        if not context.scene.kitops.last_edit or event.ctrl:
            bpy.ops.ko.save_as_insert('INVOKE_DEFAULT')

            return {'FINISHED'}

        if context.scene.kitops.last_edit:
            persistence.save_insert(path = context.scene.kitops.last_edit)
        else:
            persistence.save_insert()

        return {'FINISHED'}

class KO_OT_create_snapshot(Operator):
    bl_idname = 'ko.create_snapshot'
    bl_label = 'Create Snapshot'
    bl_description = 'Uses the current camera and scene settings to create a snapshot'

    def execute(self, context):
        path = context.scene.kitops.last_edit[:-5] if context.scene.kitops.last_edit else bpy.data.filepath[:-5]
        path = path + 'png'
        result = persistence.create_snapshot(self, context, path)
        if 'FINISHED' in result:
            bpy.ops.ko.refresh_kpacks()
        return result

class KO_OT_close_factory_scene(Operator):
    bl_idname = 'ko.close_factory_scene'
    bl_label = 'Close FACTORY Scene'
    bl_description = 'Exit the FACTORY Scene'
    bl_options = {'UNDO'}

    def execute(self, context):
        return persistence.close_factory_scene(self, context)

class KO_OT_close_thumbnail_scene(Operator):
    bl_idname = 'ko.close_thumbnail_scene'
    bl_label = 'Close THUMBNAIL Scene'
    bl_description = 'Exit the THUMBNAIL Scene'
    bl_options = {'UNDO'}

    def execute(self, context):
        persistence.remove_temp_objects(duplicates=False)

        bpy.data.scenes.remove(context.scene)

        return {'FINISHED'}


# TODO: render scene needs to be the kpack render scene if any
# TODO: progress report update
class KO_OT_render_thumbnail(Operator):
    bl_idname = 'ko.render_thumbnail'
    bl_label = 'Render thumbnail'
    bl_description = 'Render and save a thumbnail for this INSERT.\n  Shift - Import thumbnail scene\n  Ctrl - Render all thumbnails for the current working directory\n  Alt - Scale fitting\n\n  Use system console to see progress (Window > Toggle system console)'
    bl_options = {'INTERNAL'}

    render: BoolProperty(default=False)
    import_scene: BoolProperty(default=False)
    max_dimension = 1.8
    skip_scale = False

    def invoke(self, context, event):
        preference = addon.preference()
        init_active = bpy.data.objects[context.active_object.name]
        init_scene = bpy.data.scenes[context.scene.name]
        init_objects = bpy.data.objects[:]
        duplicates = []
        parents = []
        self.skip_scale = not event.alt

        if not self.import_scene:
            self.import_scene = event.shift

        

        if not self.render:

            print('\nKIT OPS beginning thumbnail rendering')
            preference.mode = 'SMART'

            

            with bpy.data.libraries.load(addon.path.thumbnail()) as (blend, imported):
                print('\tImported thumbnail rendering scene')
                imported.scenes = blend.scenes
                imported.materials = blend.materials

            

            scene = imported.scenes[0]

            

            scene.kitops.thumbnail = True
            
            context.window.scene = scene

            # return {'FINISHED'}



            for obj in scene.collection.objects:
                obj.select_set(False)
                obj.kitops.temp = True

            floor = [obj for obj in context.scene.collection.all_objects if obj.kitops.ground_box][0]

            for obj in sorted(init_objects, key=lambda o: o.name):
                duplicate = obj.copy()
                duplicate.name = 'ko_duplicate_{}'.format(obj.name)
                if duplicate.type != 'EMPTY':
                    duplicate.data = obj.data.copy()

                duplicates.append(duplicate)
                parents.append((duplicate, obj.parent))

                context.scene.collection.objects.link(duplicate)

                duplicate.kitops.insert = True
                duplicate.kitops.id = 'tmp'
                duplicate.kitops.applied = False
                duplicate.kitops['insert_target'] = floor
                duplicate.kitops.duplicate = True

                duplicate.select_set(True)
                duplicate.hide_viewport = False

                if duplicate.kitops.type == 'CUTTER' and duplicate.kitops.boolean_type == 'UNION':
                    duplicate.data.materials.clear()
                    duplicate.data.materials.append(floor.material_slots[1].material)

                elif duplicate.kitops.type == 'CUTTER' and duplicate.kitops.boolean_type in {'DIFFERENCE', 'INTERSECT'}:
                    duplicate.data.materials.clear()
                    duplicate.data.materials.append(floor.material_slots[2].material)

                elif duplicate.type in {'MESH', 'CURVE', 'SURFACE', 'FONT'}:
                    if not len(duplicate.data.materials):
                        duplicate.data.materials.append(floor.material_slots[3].material)

            context.view_layer.update()
            modifier.sort(floor)

            print('\tDuplicated objects from initial scene')
            print('\tConverted duplicates into a temporary insert')
            print('\nUpdated:')
            print('\tInsert materials')

            for duplicate, parent in parents:
                if parent and 'ko_duplicate_{}'.format(parent.name) in [duplicate.name for duplicate in duplicates]:
                    duplicate['parent'] = bpy.data.objects['ko_duplicate_{}'.format(parent.name)]

            print('\tInsert parenting')

            main = [duplicate for duplicate in duplicates if duplicate.kitops.main][0]
            context.view_layer.objects.active = main
            bpy.ops.view3d.view_camera()
            dimension = main.dimensions

            if not self.skip_scale:
                axis = 'x'
                if dimension.y > dimension.x:
                    axis = 'y'
                if dimension.z > getattr(dimension, axis):
                    axis = 'z'

                setattr(dimension, axis, self.max_dimension)

                remaining_axis = [a for a in 'xyz' if a != axis]
                setattr(main.scale, remaining_axis[0], getattr(main.scale, axis))
                setattr(main.scale, remaining_axis[1], getattr(main.scale, axis))

                print('\tInsert size (max dimension of {})'.format(self.max_dimension))

            context.scene.render.filepath = bpy.data.filepath[:-6] + '.png'
            print('\tRender path: {}'.format(context.scene.render.filepath))

            if self.import_scene:
                try:
                    bpy.ops.object.convert(target='MESH')
                except RuntimeError:
                    pass

            else:
                print('\nRendering...')
                bpy.ops.render.render(write_still=True)

            if not self.import_scene and not event.ctrl:

                print('Cleaning up\n')
                for obj in duplicates:
                    persistence.remove_object(obj)

                context.window.scene = init_scene

                for scene in imported.scenes:
                    for obj in scene.collection.objects:
                        persistence.remove_object(obj)

                    bpy.data.scenes.remove(scene, do_unlink=True)

                for material in imported.materials:
                    bpy.data.materials.remove(material, do_unlink=True, do_id_user=True, do_ui_user=True)

                context.view_layer.objects.active = init_active

                for obj in init_scene.collection.objects:
                    obj.select_set(True)
                    obj.hide_viewport = False

                print('Finished\n')

            if not self.import_scene and event.ctrl:

                print('KITOPS: Removing insert')
                for obj in duplicates:
                    persistence.remove_object(obj)

                working_directory = os.path.abspath(os.path.join(bpy.data.filepath, '..'))
                print('\n\nBeginning batch rendering in {}\n'.format(working_directory))
                for file in os.listdir(working_directory):
                    if file.endswith('.blend') and os.path.join(working_directory, file) != bpy.data.filepath:
                        location = os.path.join(working_directory, file)

                        with bpy.data.libraries.load(location) as (blend, imported):
                            print('\nImported objects from {}'.format(location))
                            imported.scenes = blend.scenes
                            imported.materials = blend.materials

                        scene = [scene for scene in imported.scenes if not scene.kitops.thumbnail][0]

                        if not len(scene.collection.objects):
                            print('Invalid file... skipping\n')
                            continue

                        elif not len([obj for obj in scene.collection.objects if obj.kitops.main]):
                            print('Invalid file... skipping\n')
                            continue

                        for obj in sorted(scene.collection.all_objects, key=lambda o: o.name):
                            context.scene.collection.objects.link(obj)

                            obj.kitops.insert = True
                            obj.kitops.id = 'tmp'
                            obj.kitops.applied = False
                            obj.kitops['insert_target'] = floor
                            obj.kitops.temp = True

                            obj.select_set(True)
                            obj.hide_viewport = False

                            if obj.kitops.type == 'CUTTER' and obj.kitops.boolean_type == 'UNION':
                                obj.data.materials.clear()
                                obj.data.materials.append(bpy.data.materials['ADD'])

                            elif obj.kitops.type == 'CUTTER' and obj.kitops.boolean_type in {'DIFFERENCE', 'INTERSECT'}:
                                obj.data.materials.clear()
                                obj.data.materials.append(bpy.data.materials['SUB'])

                            elif obj.type in {'MESH', 'CURVE', 'SURFACE', 'FONT'}:
                                if not len(obj.data.materials):
                                    obj.data.materials.append(floor.material_slots[3].material)

                        context.view_layer.update()
                        modifier.sort(floor)

                        print('\nUpdated:')
                        print('\tInsert target: {}'.format(floor.name))
                        print('\tInsert materials')

                        main = [obj for obj in context.scene.collection.all_objects if obj.kitops.main][0]
                        dimension = main.dimensions

                        if not self.skip_scale:
                            axis = 'x'
                            if dimension.y > dimension.x:
                                axis = 'y'
                            if dimension.z > getattr(dimension, axis):
                                axis = 'z'

                            setattr(dimension, axis, self.max_dimension)

                            remaining_axis = [a for a in 'xyz' if a != axis]
                            setattr(main.scale, remaining_axis[0], getattr(main.scale, axis))
                            setattr(main.scale, remaining_axis[1], getattr(main.scale, axis))

                            print('\tInsert size (max dimension of {})'.format(self.max_dimension))

                        context.scene.render.filepath = location[:-6] + '.png'
                        print('\tRender path: {}'.format(context.scene.render.filepath))
                        # context.view_layer.depsgraph.update()
                        context.area.tag_redraw()

                        print('\nRendering...')
                        bpy.ops.render.render(write_still=True)

                        print('Cleaning up\n')
                        for scene in imported.scenes:
                            for obj in scene.collection.objects:
                                persistence.remove_object(obj)

                            bpy.data.scenes.remove(scene, do_unlink=True)

                        for material in imported.materials:
                            bpy.data.materials.remove(material, do_unlink=True, do_id_user=True, do_ui_user=True)

                else:
                    context.window.scene = init_scene

                    try:
                        for scene in imported.scenes:
                            for obj in scene.collection.objects:
                                persistence.remove_object(obj)

                        bpy.data.scenes.remove(scene, do_unlink=True)

                        for material in imported.materials:
                            bpy.data.materials.remove(material, do_unlink=True, do_id_user=True, do_ui_user=True)
                    except ReferenceError:
                        pass

                    context.view_layer.objects.active = init_active

                    for obj in init_scene.collection.objects:
                        obj.select_set(True)
                        obj.hide_viewport = False

                    print('Finished\n')

        else:
            bpy.ops.render.render(write_still=True)

        return {'FINISHED'}


class KO_OT_camera_to_insert(Operator):
    bl_idname = 'ko.camera_to_insert'
    bl_label = 'Camera to INSERT'
    bl_description = 'Align camera to the INSERT'

    @classmethod
    def poll(cls, context):
        return context.scene.kitops.thumbnail

    def execute(self, context):
        # active_object = bpy.data.objects[context.active_object.name]
        selected_objects = context.selected_objects[:]
        objects = context.scene.collection.all_objects[:]
        # other_scene_objects = [scene for scene in bpy.data.scenes[:] if not scene.kitops.thumbnail][0].collection.all_objects[:]

        for obj in objects:
            if obj.kitops.temp:
                obj.select_set(False)
                continue

            obj.select_set(True)

        for obj in objects:
            if obj.kitops.material_base:
                obj.select_set(True)

        bpy.ops.view3d.camera_to_view_selected()

        for obj in objects:
            if obj in selected_objects:
                obj.select_set(True)
                continue

            obj.select_set(False)

        return {'FINISHED'}



def calc_location(matrix_world, bm, face_index, orig_location):
    '''calculate snap position'''
    preference = addon.preference()
    if preference.snap_mode == 'FACE':
        # return location based on face.
        bm.faces.ensure_lookup_table()
        face = bm.faces[face_index]
        location = matrix_world @ face.calc_center_median()
        return location
    elif preference.snap_mode == 'EDGE':
        if preference.snap_mode_edge == 'NEAREST':
            # find nearest edge in face based on projection.
            bm.faces.ensure_lookup_table()
            face = bm.faces[face_index]
            new_location = matrix_world @ orig_location
            def point_on_edge(e):
                edge_vector = (matrix_world @ e.verts[0].co - matrix_world @ e.verts[1].co)
                point, _ = mathutils.geometry.intersect_point_line(new_location, matrix_world @ e.verts[0].co, matrix_world @ e.verts[1].co)
                return point

            point_map = {}
            for e in face.edges:
                point_map[e.index] = point_on_edge(e)

            def closest_distance(key):
                point = point_map[key]
                return (new_location - point).length

            closest_index = min(point_map.keys(), key=closest_distance)

            return point_map[closest_index]
        else:
            # find the nearest edge center.
            bm.faces.ensure_lookup_table()
            face = bm.faces[face_index]
            new_location = matrix_world @ orig_location
            def edge_center(e):
                edge_center = (matrix_world @ e.verts[0].co + matrix_world @ e.verts[1].co) / 2
                return edge_center

            edge_map = {}
            for e in face.edges:
                edge_map[e.index] = edge_center(e)

            def closest_distance(key):
                point = edge_map[key]
                return (new_location - point).length

            closest_index = min(edge_map.keys(), key=closest_distance)

            return edge_map[closest_index]

    elif preference.snap_mode == 'VERTEX':
        # find nearest vertex in face.
        bm.faces.ensure_lookup_table()
        face = bm.faces[face_index]
        new_location = matrix_world @ orig_location
        def dist_to_vert(v):
            return (new_location - matrix_world @ v.co).length
        vertex = min(face.verts, key=dist_to_vert)
        return matrix_world @ vertex.co

    # just return the original location if we got this far.
    return orig_location


def display_refs(layout, refs, start, end):
    '''Display a list of references to KPACKS given a range.'''

    option = addon.option()

    box = layout.box()
    flow = box.grid_flow(row_major=True, even_rows=True, even_columns=True, align=False, columns=end-start)

    for i in range(start, end):

        row = flow.row(align=False)
        row.alignment='CENTER'
        try:
            ref = refs[i]
            if ref.name in option.kpack.categories:
                category = option.kpack.categories[ref.name]

                #determine icon
                icon_id = kitops_update.get_icon_id(category)

                #determine active
                is_active = category.name == option.kpack.categories[option.kpack.active_index].name

                #determine text
                text=''
                if not icon_id:
                    text=''.join(x for x in category.name if x.isalpha())[0:2]

                row.operator("ko.select_kpack", text=text, emboss=is_active, depress=is_active, icon_value=icon_id).kpack_name = category.name


        except IndexError:
            # add a blank operator placeholder.
            row.operator("ko.select_kpack", text='', emboss=False, depress=False).kpack_name = ''
            pass




def draw_fvs_rcts(column):
    preference = addon.preference()

    #favorites
    if preference.show_favorites:

        row = column.row(align=True)
        label_col = row.column(align=True)
        label_box = label_col.box()
        label_box.prop(preference, 'show_favorites', text="", icon="SOLO_ON", emboss=False)

        btns_row = label_col.box().row()
        btns_row.alignment='CENTER'
        btns_row.scale_x=0.5
        btns_row.scale_y=0.5

        btns_row.operator("ko.move_fav_active_kpack", text='', icon='TRIA_LEFT', emboss=False).direction = -1
        btns_row.operator("ko.move_fav_active_kpack", text='', icon='TRIA_RIGHT', emboss=False).direction = 1

        
        favorites = preference.favorites
        if len(favorites):




            box_cols = row.column(align=True)
            # build 3 rows of favorites
            row_limit = int(constants.favorites_limit / 3) 
            for i in range(0, 3):
                sub_row_limit = i * row_limit
                if len(favorites) - sub_row_limit > 0:
                    display_refs(box_cols, favorites, sub_row_limit, sub_row_limit + row_limit)
            
            # backwards/forwards buttons
            back_forth_col = box_cols.column(align=True)
            back_forth_col.alignment = 'RIGHT'
            back_forth_row = back_forth_col.row(align=True)
            back_forth_row.alignment='RIGHT'
            

        else:
            row.box().label(text="No Favorites selected")
        
        column.separator()

    # recently used
    if preference.show_recents:
        row = column.row(align=True)
        label_row = row.box()
        label_row.prop(preference, 'show_recents', text="", icon="TIME", emboss=False)

        recently_used= preference.recently_used
        display_refs(row, recently_used, 0, constants.recently_used_limit)
        column.separator()




class KO_OT_add_favorite(Operator):
    bl_idname = 'ko.add_favorite'
    bl_label = 'Add a favorite KPACK'
    bl_description = 'Add a favorite KPACK'
    bl_options = {'INTERNAL'}

    kpack_name : StringProperty()

    def execute(self, context):
        preference = addon.preference()
        preference.favorites.add().name = self.kpack_name
        return {'FINISHED'}


class KO_OT_remove_favorite(Operator):
    bl_idname = 'ko.remove_favorite'
    bl_label = 'Remove a favorite KPACK'
    bl_description = 'Remove a favorite KPACK'
    bl_options = {'INTERNAL'}

    kpack_name : StringProperty()

    def execute(self, context):
        preference = addon.preference()
        preference.favorites.remove(preference.favorites.find(self.kpack_name))
        return {'FINISHED'}


class KO_OT_select_kpack(Operator):
    bl_idname = 'ko.select_kpack'
    bl_label = 'Select'
    bl_options = {'INTERNAL'}

    kpack_name : StringProperty()

    @classmethod
    def description(self, context, properties):
        if properties.kpack_name:
            return properties.kpack_name
        return ''

    def execute(self, context):
        kpack_name = self.kpack_name
        option = addon.option()
        if kpack_name in option.kpack.categories:
            option.kpacks = kpack_name
            return {'FINISHED'}
        return {'CANCELLED'}


class KO_OT_move_fav_active_kpack(Operator):
    bl_idname = 'ko.move_fav_active_kpack'
    bl_label = 'Move Favorite'
    bl_options = {'INTERNAL'}

    direction : IntProperty()

    def execute(self, context):
        preference = addon.preference()
        option = addon.option()
        active_cat = option.kpack.categories[option.kpack.active_index]

        if active_cat.name in preference.favorites:
            active_cat_index = preference.favorites.find(active_cat.name)

            neighbor = max(0, active_cat_index + self.direction)
            
            preference.favorites.move(neighbor, active_cat_index)
            return {'FINISHED'}
        return {'CANCELLED'}


class KO_OT_clear_favorites(Operator):
    bl_idname = 'ko.clear_favorites'
    bl_label = 'Clear Favorites'
    bl_description = 'Clear All Favorites'
    bl_options = {'INTERNAL', 'UNDO'}

    def execute(self, context):
        preference = addon.preference()
        preference.favorites.clear()

        #redraw all regions to update views.
        for window in context.window_manager.windows:
            for area in window.screen.areas:
                for region in area.regions:
                    region.tag_redraw()

        return {'FINISHED'}

class KO_OT_clear_favorites_confirm(Operator):
    """This will clear all favorites. Are you sure?"""
    bl_idname = 'ko.clear_favorites_confirm'
    bl_label = 'Clear Favorites'
    bl_description = 'Clear All Favorites'
    bl_options = {'INTERNAL', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        bpy.ops.ko.clear_favorites('INVOKE_DEFAULT')
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)


def replace_objs(self, context, objs_to_replace):

    option = addon.option()
    preference = addon.preference()

    for obj in bpy.data.objects:
        obj.select_set(False)

    context.view_layer.update()

    category = option.kpack.categories[option.kpack.active_index]
    location = category.blends[category.active_index].location
    self.location = location

    new_insert_objs = []

    collections_to_delete = []

    for obj_to_replace in objs_to_replace:

        old_mode = preference.mode
        preference.mode = 'SMART'
        # bring in the new insert.
        # ignore any auto scaling preferences.
        old_auto_scale = preference.auto_scale
        preference.auto_scale = False
        try:
            
            if obj_to_replace.kitops.id:
                self.boolean_target = obj_to_replace.kitops.reserved_target
            elif hasattr(obj_to_replace, 'bc') and obj_to_replace.bc.target:
                self.boolean_target = obj_to_replace.bc.target

            uid = insert.add(self, context)

            for obj in bpy.data.objects:
                obj.select_set(False)

            #copy over necessary properties, mirrors etc.
            insert_obj = insert.get_insert(uid)
            # return {'FINISHED'}
            if insert_obj == None:
                return

            # copy matrix
            location_tmp = obj_to_replace.location.copy()
            matrix_world_tmp = obj_to_replace.matrix_world.copy()
            rotation_euler_tmp = obj_to_replace.rotation_euler.copy() 

            # calc scale to fit
            insert_obj_bounds = [insert_obj.matrix_world @ Vector(point[:]) for point in insert_obj.bound_box[:]]
            insert_obj_bound = math.coordinates_dimension(insert_obj_bounds)


            # decompose the matrix to not take into account rotation.
            euler = Euler(map(radians, (0, 0, 0)), 'XYZ')
            loc, rot, scale = obj_to_replace.matrix_world.decompose()

            smat = Matrix()
            for i in range(3):
                smat[i][i] = scale[i]
            mat = Matrix.Translation(loc) * euler.to_matrix().to_4x4() * smat
        #
            obj_to_replace_bounds = [mat @ Vector(point[:]) for point in obj_to_replace.bound_box[:]]
            obj_to_replace_bound = math.coordinates_dimension(obj_to_replace_bounds)

            ratios =[]
            axes = ['x', 'y']
            for axis in axes:
                insert_obj_axis = getattr(insert_obj_bound, axis) if getattr(insert_obj_bound, axis) != 0 else 1
                ratios.append(abs(getattr(obj_to_replace_bound, axis)) / insert_obj_axis)


            # finally, apply all this calculation to the translation.
            insert_obj.location = location_tmp
            insert_obj.rotation_euler = rotation_euler_tmp
            insert_obj.scale *= min(ratios)
            
            context.view_layer.objects.active = insert_obj
            insert_obj.select_set(True)

            if obj_to_replace.kitops.mirror_x:
                insert_obj.kitops.mirror_x = obj_to_replace.kitops.mirror_x
            if obj_to_replace.kitops.mirror_y:
                insert_obj.kitops.mirror_y = obj_to_replace.kitops.mirror_y
            if obj_to_replace.kitops.mirror_z:
                insert_obj.kitops.mirror_z = obj_to_replace.kitops.mirror_z
            for obj in bpy.data.objects:
                obj.select_set(False)
            # context.view_layer.update()

            # notify other add-ons of replacement.
            listeners.insertReplacementSubject.notify(obj_to_replace, insert_obj)

            #delete the objects.
            collections_to_delete.extend(obj_to_replace.users_collection[:])

            if obj_to_replace.kitops.id:
                # delete the insert
                insert.delete_hierarchy(obj_to_replace, self.boolean_target)
            elif hasattr(obj_to_replace, 'bc') and obj_to_replace.bc.target:
                # delete the box cutter, removing modifiers from target.
                target = obj_to_replace.bc.target
                modifiers_to_remove = [mod for mod in target.modifiers if mod.type == "BOOLEAN" and hasattr(mod, 'object') and mod.object == obj_to_replace]

                # attempt to move the new insert's boolean modifier to the right position.
                if len(modifiers_to_remove) == 1 and insert_obj.kitops.reserved_target == target:
                    bool_mods = [m for m in target.modifiers if m.type == 'BOOLEAN' and m.object == insert_obj]
                    if len(bool_mods) == 1:
                        new_insert_target_mod_index = target.modifiers.find(bool_mods[0].name)
                        target_index =  target.modifiers.find(modifiers_to_remove[0].name)
                        mod_name = bool_mods[0].name
                        while target.modifiers.find(mod_name) != 0:
                            bpy.ops.object.modifier_move_up({'object': target}, modifier=mod_name)
                        while target.modifiers.find(mod_name) != target_index:
                            bpy.ops.object.modifier_move_down({'object': target}, modifier=mod_name)


                for mod in modifiers_to_remove:
                    target.modifiers.remove(mod)

                persistence.remove_object(obj_to_replace)

            new_insert_objs.append(insert_obj)

            context.view_layer.update()

        finally:
            preference.auto_scale = old_auto_scale
            preference.mode = old_mode

    collections_to_delete = list(set(collections_to_delete))
    for collection in collections_to_delete:
        if not len(collection.all_objects):
            bpy.data.collections.remove(collection)

    if len(new_insert_objs):
        context.view_layer.objects.active = new_insert_objs[0]
        for new_insert_obj in new_insert_objs:
            new_insert_obj.select_set(True)


class KO_OT_replace_insert(Operator):
    bl_idname = 'ko.replace_insert'
    bl_label = 'Replace Inserts'
    bl_description = 'Replace selected inserts in the scene with this one. \nShift key replaces ALL INSERTS of selected type(s) throughout the scene'
    bl_options = {'INTERNAL', 'UNDO'}

    # these are used for the insert module.
    main = None
    boolean_target = None
    inserts = list()
    init_active = None
    init_selected = list()
    location : StringProperty()

    # to be passed so that the inserts module can operate.
    material: BoolProperty(name='Material', default=False)
    material_link: BoolProperty(name='Link Materials')
    duplicate = None
    import_material = None
    objs_to_replace = []
    box_cutters_to_replace = []

    def invoke(self, context, event):
        if event.shift:
            # gather up all the insert type names and select the relevant objects in the scene.
            insert_names = [o.kitops.insert_name for o in context.scene.objects if o.kitops.insert and o.select_get()]
            insert_names = list(set(insert_names))
            self.objs_to_replace = [o.kitops.main_object for o in context.scene.objects if o.users > 0 and  o.kitops.insert and o.kitops.insert_name in insert_names]
        else:
            self.objs_to_replace = [o.kitops.main_object for o in context.scene.objects if o.users > 0 and  o.kitops.insert and o.select_get()]


         # if there are box cutters we can also replace these
        self.objs_to_replace.extend( [o for o in context.scene.objects if o.users > 0 and o.select_get() and hasattr(o, 'bc') and o.bc.target])

        # make sure this is a unique list.
        self.objs_to_replace = list(set(self.objs_to_replace))

        return self.execute(context)


    @classmethod
    def poll(cls, context):
        return len([o for o in context.scene.objects if o.select_get() and (o.kitops.insert or  (hasattr(o, 'bc') and o.bc.target))])

    def execute(self, context):

        if not len(self.objs_to_replace):
            return {'CANCELLED'}

        if 'INSERTS' not in bpy.data.collections:
            context.scene.collection.children.link(bpy.data.collections.new(name='INSERTS'))

        if self.objs_to_replace:
            replace_objs(self, context, self.objs_to_replace)

        return {'FINISHED'}



classes = [
    KO_OT_edit_insert,
    KO_OT_edit_insert_confirm,
    KO_OT_create_insert,
    KO_OT_create_insert_material,
    KO_OT_save_as_insert,
    KO_OT_save_insert,
    KO_OT_create_snapshot,
    KO_OT_close_factory_scene,
    KO_OT_close_thumbnail_scene,
    KO_OT_render_thumbnail,
    KO_OT_camera_to_insert,
    KO_OT_select_kpack,
    KO_OT_add_favorite,
    KO_OT_remove_favorite,
    KO_OT_move_fav_active_kpack,
    KO_OT_clear_favorites,
    KO_OT_clear_favorites_confirm,
    KO_OT_replace_insert
]


def register():
    for cls in classes:
        register_class(cls)


def unregister():
    for cls in classes:
        unregister_class(cls)
