# Global variables to maintain track of enum properties.

# These are global references to address a known issue with the Blender EnumProperty handling items: https://docs.blender.org/api/current/bpy.props.html?highlight=enumprop#bpy.props.EnumProperty
kitops_category_enums = []
kitops_insert_enum_map = {}