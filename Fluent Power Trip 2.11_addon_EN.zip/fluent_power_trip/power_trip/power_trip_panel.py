import bpy
from ..helpers import *

class FLUENT_PT_PowerTrip_Panel(bpy.types.Panel):
    "Fluent tool box"
    bl_label = "Power Trip"
    bl_name = "Power Trip"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'Fluent'
    bl_parent_id = "FLUENT_PT_Basic_Panel"

    def draw(self, context):
        icons, gl_images = load_icons()
        wire_ico = icons.get("wire")
        pipe_ico = icons.get("pipe")
        plate_ico = icons.get("plate")
        grid_ico = icons.get("grid")
        cloth_ico = icons.get("cloth")
        screw_ico = icons.get("screw")

        layout = self.layout
        box = layout.column(align=True)
        line_01 = box.row(align=True)
        line_01.scale_x = 1.2
        line_01.scale_y = 1.5
        line_01.operator("fluent.plates", text='Plate', icon_value=plate_ico.icon_id)
        line_01.operator("fluent.grids", text='Grid', icon_value=grid_ico.icon_id).operation = 'ADD'
        line_01.operator("fluent.screw", text='Screws', icon_value=screw_ico.icon_id).operation = 'ADD'

        line_02 = box.row(align=True)
        line_02.scale_x = 1.2
        line_02.scale_y = 1.5
        line_02.operator("fluent.wire", text='Wire', icon_value=wire_ico.icon_id).operation = 'ADD'
        line_02.operator("fluent.pipe", text='Pipe', icon_value=pipe_ico.icon_id).operation = 'ADD'

        line_03 = box.row(align=True)
        line_03.scale_x = 1.2
        line_03.scale_y = 1.5
        line_03.operator("fluent.clothpanel", text='Cloth panel', icon_value=cloth_ico.icon_id)
        line_03.operator("fluent.clothsettings", text='Cloth settings')

classes = FLUENT_PT_PowerTrip_Panel