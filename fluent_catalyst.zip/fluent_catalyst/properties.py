import os

from bpy.props import StringProperty, BoolProperty, EnumProperty, CollectionProperty, IntProperty, FloatProperty
from bpy_types import PropertyGroup

from .Tools.helper import get_addon_preferences


def menu_items(entity, context):
    menus = []
    for menu in context.scene.FLUENT_CATALYST_CREATE.menus_coll:
        if isinstance(entity, MenusCollection) and entity.name == menu.name:
            continue

        name = menu.name
        menus.append((name, name, name))

    return menus


class InputsCollection(PropertyGroup):
    input_name: StringProperty()
    name: StringProperty()
    type: EnumProperty(
        name='Type',
        items=(
            ("INTEGER", "Integer", "Integer"),
            ("FLOAT", "Float", "Float"),
            ("BOOLEAN", "Boolean", "Boolean"),
            ("MATERIAL", "Material", "Material"),
            ("OBJECT", "Object", "Object")
        ),
        default='INTEGER'
    )
    menu: EnumProperty(
        name='Menu',
        items=menu_items
    )
    show: BoolProperty(
        default=True,
        name="Show in the menu",
        description="Show/hide from the Fluent Catalyst menu",
    )
    min: FloatProperty()
    max: FloatProperty()


class MenusCollection(PropertyGroup):
    name: StringProperty()
    parent: EnumProperty(
        name='Prent menu',
        items=menu_items
    )


class AssetsLibrariesCollection(PropertyGroup):
    def hide_show_lib(self, context):
        lib_path = os.path.join(get_addon_preferences().assets_libraries_path, self.name)
        hidden_file_path = os.path.join(lib_path, ".ishidden")

        if self.show:
            if os.path.exists(hidden_file_path):
                os.remove(hidden_file_path)

            return

        if not os.path.exists(hidden_file_path):
            fp = open(hidden_file_path, 'w')
            fp.close()

    name: StringProperty()
    show: BoolProperty(
        default=True,
        name="Show in the library list",
        description="Show/hide from the Fluent Catalyst menu",
        update=hide_show_lib
    )


class CreateAssetSceneProperties(PropertyGroup):
    def assets_lib_items(self, context):
        libraries = []
        for lib in get_addon_preferences().assets_libraries:
            if not lib.show:
                continue
            libraries.append((lib.name, lib.name, lib.name))

        return libraries

    def geometry_nodes_items(self, context):
        geometry_nodes = []
        for geo in self.geometry_nodes:
            node_group = geo.node_group
            if node_group is None:
                continue

            geometry_nodes.append((node_group.name, node_group.name, node_group.name))

        return geometry_nodes

    inputs_coll: CollectionProperty(type=InputsCollection)
    inputs_index: IntProperty(name="Input list of the geometry node for the selected object")

    menus_coll: CollectionProperty(type=MenusCollection)
    menus_index: IntProperty(name="Menu list for the selected object")

    is_init_done: BoolProperty(
        description="is_init_done",
        name="is_init_done",
        default=False,
    )

    assets_libraries: EnumProperty(
        name="Assets library",
        items=assets_lib_items
    )
    new_assets_library: StringProperty(
        name="New asset library"
    )
    create_step: IntProperty(default=1)
    error_preview: BoolProperty(
        default=False,
    )

    creation_steps_done = []
    in_creation: BoolProperty(
        default=False,
    )
    creation_done: BoolProperty(
        default=False,
    )

    use_asset_materials: BoolProperty(
        default=True,
    )

    geometry_nodes = []
    geometry_nodes_list: EnumProperty(
        name="Geometry modifier",
        items=geometry_nodes_items
    )

    asset_import_enabled: BoolProperty(
        description="asset_import_enabled",
        name="asset_import_enabled",
        default=False,
    )
    in_asset_deletion: BoolProperty(
        default=False,
    )
    in_asset_deleted: BoolProperty(
        description="To prevent chain delete in the logic",
        default=False,
    )
