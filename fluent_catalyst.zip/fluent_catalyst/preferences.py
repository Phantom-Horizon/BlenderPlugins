import bpy
from bpy.props import StringProperty, CollectionProperty, IntProperty
from bpy_types import AddonPreferences, Operator

from .operators import FLUENT_CATALYST_OT_RELOAD_LIBRARIES, FLUENT_CATALYST_OT_IMPORT_LIBRARY
from .Tools.helper import init_libraries
from .properties import AssetsLibrariesCollection


class FluentCatalystAddonPreferences(AddonPreferences):
    bl_idname = "fluent_catalyst"

    font_size: bpy.props.IntProperty(
        description='UI font size',
        name='Font size',
        default=18
    )

    icon_size: bpy.props.EnumProperty(
        description='Size of icons',
        name='Icon size',
        items=(('32', '32', '32'),
               ('48', '48', '48'),
               ),
        default='32'
    )

    language: bpy.props.EnumProperty(
        items=(
            ("ENGLISH", "English", "ENGLISH"),
            ("FRANCAIS", "Français", "FRANCAIS"),
            ("CHINESE", "Chinese", "CHINESE"),
            ("TRAD_CHINESE", "Traditional Chinese", "TRAD_CHINESE"),
            ("JAPANESE", "Japanese", "JAPANESE"),
            ("RUSSIAN", "Russian", "RUSSIAN"),
            ("DEUTSCH", "Deutsch", "DEUTSCH"),
        ),
        default='ENGLISH'
    )

    last_version: bpy.props.StringProperty(
        description="last version",
        name="last_version",
        default="(0.0.1)"
    )

    highlight_text: bpy.props.FloatVectorProperty(
        name="Color of highlight text",
        subtype='COLOR',
        size=4,
        default=(0, 0.58, 1, 1)
    )

    bg_color: bpy.props.FloatVectorProperty(
        name="Color of background text",
        subtype='COLOR',
        size=4,
        default=(0.21, 0.21, 0.21, 1)
    )

    active_bg_color: bpy.props.FloatVectorProperty(
        name="Color of active background text",
        subtype='COLOR',
        size=4,
        default=(0, 0.58, 1, 1)
    )

    overlay_color: bpy.props.FloatVectorProperty(
        name="Color of menu overlay",
        subtype='COLOR',
        size=4,
        default=[0.1, 0.1, 0.1, 0.5]
    )

    assets_libraries_path: StringProperty(
        name="Path of installed libraries",
        description="Path of installed libraries",
        default="",
        subtype="DIR_PATH"
    )
    assets_libraries: CollectionProperty(type=AssetsLibrariesCollection)
    assets_libraries_index: IntProperty(name="List of installed libraries")

    def draw(self, context):
        init_libraries()

        layout = self.layout

        box = layout.box()
        box.label(text="After change, save your preferences and restart Blender.")

        box = layout.box()
        box.label(text='--- Libraries ---')
        row = box.row()
        row.prop(self, "assets_libraries_path")
        row.operator(FLUENT_CATALYST_OT_RELOAD_LIBRARIES.bl_idname, text="", icon="FILE_REFRESH")
        row.operator(FLUENT_CATALYST_OT_IMPORT_LIBRARY.bl_idname, text="", icon="IMPORT")

        col = box.column()
        col.template_list(
            "FLUENT_CATALYST_UL_assets_libraries", "", self, "assets_libraries",
            self, "assets_libraries_index",
            rows=max(len(self.assets_libraries), 6)
        )

        box = layout.box()
        box.label(text='--- Display ---')
        box.prop(self, "font_size")
        box.prop(self, "icon_size")
        box.prop(self, "language", text="Language ")
        box.label(text="Translation is in progress. Whole text isn't translated.")
        box.prop(self, "highlight_text")
        box.prop(self, "bg_color")
        box.prop(self, "active_bg_color")
        box.prop(self, "overlay_color")
