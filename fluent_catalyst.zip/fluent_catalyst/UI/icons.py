import bpy
import os
from os.path import join, dirname, realpath
import bgl

# Chargement des icones
fa_icons_collection = {}
fa_icons_loaded = False

icons_dir = join(dirname(realpath(__file__)))
image_size = (32, 32)

fa_icons_converter_collection = {}


def load_icons():
    global fa_icons_collection
    global fa_icons_loaded
    global fa_icons_converter_collection

    if fa_icons_loaded:
        return fa_icons_collection["main"], fa_icons_converter_collection
    custom_icons = bpy.utils.previews.new()

    icons_dir = join(dirname(realpath(__file__)), 'icons')

    for f in os.listdir(icons_dir):
        f = f.split('.png')
        if len(f) == 2:
            custom_icons.load(f[0], join(icons_dir, f[0] + '.png'), 'IMAGE')
            converter = GlImageFromPreview(custom_icons.get(f[0]))
            converter.gl_load()
            fa_icons_converter_collection[f[0]] = converter

    fa_icons_collection["main"] = custom_icons
    fa_icons_loaded = True

    return fa_icons_collection["main"], fa_icons_converter_collection


def clear_icons():
    global fa_icons_loaded
    for icon in fa_icons_collection.values():
        bpy.utils.previews.remove(icon)
    fa_icons_collection.clear()
    fa_icons_loaded = False

class GlImageFromPreview:

    __slots__ = ('_bo', 'preview')

    def __init__(self, preview):
        self._bo = None
        self.preview = preview

    def gl_load(self):
        _p = self.preview
        _bo = bgl.Buffer(bgl.GL_INT, [1])
        _pix = _p.image_pixels_float[:]
        w, h = _p.image_size
        buf = bgl.Buffer(bgl.GL_FLOAT, len(_pix), _pix)
        bgl.glGenTextures(2, _bo)
        bgl.glBindTexture(bgl.GL_TEXTURE_2D, _bo[-1])
        bgl.glTexImage2D(bgl.GL_TEXTURE_2D, 0, bgl.GL_RGBA, w,
                         h, 0, bgl.GL_RGBA, bgl.GL_FLOAT, buf)
        bgl.glTexParameteri(bgl.GL_TEXTURE_2D,
                            bgl.GL_TEXTURE_MIN_FILTER, bgl.GL_LINEAR)
        bgl.glTexParameteri(bgl.GL_TEXTURE_2D,
                            bgl.GL_TEXTURE_MAG_FILTER, bgl.GL_LINEAR)
        bgl.glBindTexture(bgl.GL_TEXTURE_2D, 0)
        self._bo = _bo

    def gl_free(self):
        if self._bo is not None:
            bgl.glDeleteTextures(2, self._bo)
        self._bo = None

    @property
    def bindcode(self):
        if self._bo is None:
            return 0
        return self._bo[-1]