import bpy
from ..Tools.helper import init_default_library_path, init_libraries, init_geometry_nodes, \
    init_libraries_previews, is_selected_library_empty
from ..operators import FLUENT_CATALYST_OT_NEXT_STEP, FLUENT_CATALYST_OT_PREVIOUS_STEP, FLUENT_CATALYST_OT_ADD_MENU, \
    FLUENT_CATALYST_OT_ADD_LIBRARY, FLUENT_CATALYST_OT_NEW_LIBRARY, FLUENT_CATALYST_OT_GO_BACK_CREATION, \
    FLUENT_CATALYST_OT_REFRESH_INPUTS, FLUENT_CATALYST_OT_IMPORT_ASSET, FLUENT_CATALYST_OT_REMOVE_ASSET, \
    FLUENT_CATALYST_OT_REMOVE_ASSET_TOGGLE
from .modal_geometry_menu import FLUENT_CATALYST_OT_GeometryMenu


class FLUENT_CATALYST_PT_Panel(bpy.types.Panel):
    bl_idname = 'FLUENT_CATALYST_PT_Panel'
    bl_label = "Fluent Catalyst"
    bl_name = "Fluent Catalyst"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'Fluent'

    def __init__(self):
        init_default_library_path()
        init_libraries()
        init_libraries_previews()

    def draw(self, context):
        layout = self.layout
        row = layout.row(align=True)
        row.operator(FLUENT_CATALYST_OT_GeometryMenu.bl_idname, text='Edit Selected Asset', icon='OUTLINER_DATA_GP_LAYER')

        fluent_catalyst_create = context.scene.FLUENT_CATALYST_CREATE
        box = layout.box()
        column = box.column(align=True)
        row = column.row(align=True)
        row.scale_y = 1.5
        row.prop(fluent_catalyst_create, "assets_libraries")

        column = box.column(align=True)
        row = column.row(align=True)
        row.scale_y = 1.5

        if is_selected_library_empty():
            row.label(text='No assets in this library yet')
            row = column.row(align=True)
            row.label(text='Create new assets in the "Create Fluent Catalyst Asset" section')
        else:
            row.template_icon_view(
                bpy.context.window_manager, "fa_libraries_%s" % fluent_catalyst_create.assets_libraries,
                show_labels=True
            )

            row = layout.row()
            row.scale_y = 1.5
            row.scale_x = 6
            row.operator(FLUENT_CATALYST_OT_IMPORT_ASSET.bl_idname, text="", icon='ADD')
            row.operator(FLUENT_CATALYST_OT_REMOVE_ASSET_TOGGLE.bl_idname, text="", icon='CANCEL')

            if fluent_catalyst_create.in_asset_deletion:
                row = column.row(align=True)
                row.label(text="Deletion mode enabled, select an asset to remove it from library", icon="ERROR")


class FLUENT_CREATE_PT_Panel(bpy.types.Panel):
    bl_label = "Create Fluent Catalyst Asset"
    bl_name = "Create Fluent Catalyst Asset"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'Fluent'
    bl_parent_id = "FLUENT_CATALYST_PT_Panel"

    asset_name = ''

    def __init__(self):
        init_default_library_path()
        init_libraries()
        init_geometry_nodes()

        selected_object = bpy.context.view_layer.objects.active
        self.asset_name = '' if selected_object is None else selected_object.name

        if all(value in bpy.context.scene.FLUENT_CATALYST_CREATE.creation_steps_done for value in ['MENU', 'ASSET_FILE', 'PREVIEW', 'LIB_PREVIEW_REFRESHED']):
            bpy.context.scene.FLUENT_CATALYST_CREATE.creation_done = True
            bpy.context.scene.FLUENT_CATALYST_CREATE.in_creation = False

    def draw(self, context):
        layout = self.layout
        fluent_catalyst_create = context.scene.FLUENT_CATALYST_CREATE

        if len(fluent_catalyst_create.geometry_nodes) == 0:
            row = layout.row()
            row.label(text="To create a Fluent Catalyst, please select an object", icon="ERROR")
            row = layout.row()
            row.label(text="Or the object has to have at least one Geometry Nodes modifier")
            return

        if fluent_catalyst_create.in_creation:
            menu_status_icon = asset_file_status = preview_status = lib_preview_status = 'CHECKBOX_DEHLT'
            if 'MENU' in fluent_catalyst_create.creation_steps_done:
                menu_status_icon = 'CHECKBOX_HLT'
            if 'ASSET_FILE' in fluent_catalyst_create.creation_steps_done:
                asset_file_status = 'CHECKBOX_HLT'
            if 'PREVIEW' in fluent_catalyst_create.creation_steps_done:
                preview_status = 'CHECKBOX_HLT'
            if 'LIB_PREVIEW_REFRESHED' in fluent_catalyst_create.creation_steps_done:
                lib_preview_status = 'CHECKBOX_HLT'

            if fluent_catalyst_create.error_preview:
                preview_status = 'ERROR'

            row = layout.row()
            row.label(text="Custom menu generation", icon=menu_status_icon)
            row = layout.row()
            row.label(text="Asset blend file generation", icon=asset_file_status)
            row = layout.row()
            row.label(text="Preview generation", icon=preview_status)
            row = layout.row()
            row.label(text="Library previews refreshed", icon=lib_preview_status)

            if fluent_catalyst_create.error_preview:
                row = layout.row()
                row.scale_y = 1.2
                row.label(text="Error while generating the preview of \"" + fluent_catalyst_create.assets_libraries + "\".", icon="ERROR")

                row = layout.row()
                row.scale_y = 1.5
                row.operator(FLUENT_CATALYST_OT_PREVIOUS_STEP.bl_idname, text="Go back", icon="TRIA_LEFT")

            return

        if fluent_catalyst_create.creation_done:
            row = layout.row()
            row.scale_y = 1.2
            row.label(text="New Asset Created and added to \"" + fluent_catalyst_create.assets_libraries + "\".")

            row = layout.row()
            row.scale_y = 1.5
            row.operator(FLUENT_CATALYST_OT_GO_BACK_CREATION.bl_idname, text="Go to creation menu", icon="TRIA_LEFT")

            return

        if fluent_catalyst_create.create_step == 1:
            self.create_step_one(context, layout)
        elif fluent_catalyst_create.create_step == 2:
            self.create_step_two(context, layout)
        elif fluent_catalyst_create.create_step == 3:
            self.create_step_three(context, layout)

    def create_step_one(self, context, layout):
        row = layout.row()
        fluent_catalyst_create = context.scene.FLUENT_CATALYST_CREATE
        row.label(text="Name : %s" % self.asset_name)

        row = layout.row()
        row.prop(fluent_catalyst_create, "assets_libraries", text="Library")
        row.prop(fluent_catalyst_create, "new_assets_library", text="")
        row.operator(FLUENT_CATALYST_OT_NEW_LIBRARY.bl_idname, text="Add new library")

        row = layout.row()
        row.prop(fluent_catalyst_create, "geometry_nodes_list")

        row = layout.row()
        row.scale_y = 1.5
        row.operator(FLUENT_CATALYST_OT_NEXT_STEP.bl_idname, text="Next", icon="TRIA_RIGHT")

    def create_step_three(self, context, layout):
        row = layout.row()
        fluent_catalyst_create = context.scene.FLUENT_CATALYST_CREATE
        row.label(text="Preview render settings")

        row = layout.row()
        row.prop(fluent_catalyst_create, "use_asset_materials", text="Use asset materials")

        if not fluent_catalyst_create.use_asset_materials:
            row = layout.row()
            row.label(text="It will use the material \"ASSET\" of the preview_scene.blend file", icon="ERROR")
            row = layout.row()
            row.label(text="You can edit it by changing it in the preview_scene.blend file")

        row = layout.row()
        row.scale_y = 1.5
        row.operator(FLUENT_CATALYST_OT_PREVIOUS_STEP.bl_idname, text="Previous", icon="TRIA_LEFT")

        button_text = "Add to \"" + context.scene.FLUENT_CATALYST_CREATE.assets_libraries + "\""
        row.operator(FLUENT_CATALYST_OT_ADD_LIBRARY.bl_idname, text=button_text, icon="OUTLINER_OB_GROUP_INSTANCE")

    def create_step_two(self, context, layout):
        row = layout.row()
        row.label(text="Create your Fluent Catalyst menu for : %s" % self.asset_name)
        row.operator(FLUENT_CATALYST_OT_REFRESH_INPUTS.bl_idname, text="", icon="FILE_REFRESH")
        box = layout.box()
        box.label(text="Asset menu inputs")

        column = box.column()
        row = column.row(align=True)
        split = row.split(factor=0.47)
        r = split.row()
        r.label(text="Name")
        rs = split.split(factor=0.5)
        rs.label(text="Type")
        rs.label(text="Menu")
        col = box.column()
        col.template_list(
            "FLUENT_CATALYST_UL_inputs", "", context.scene.FLUENT_CATALYST_CREATE, "inputs_coll",
            context.scene.FLUENT_CATALYST_CREATE, "inputs_index",
            rows=max(len(context.scene.FLUENT_CATALYST_CREATE.inputs_coll), 6)
        )

        box = layout.box()
        box.label(text="Menus and sub-menus")

        column = box.column()
        row = column.row(align=True)
        split = row.split(factor=0.47)
        r = split.row()
        r.label(text="Name")
        rs = split.split(factor=0.4)
        rs.label(text="Parent menu")
        col = box.column()
        col.template_list(
            "FLUENT_CATALYST_UL_menus", "", context.scene.FLUENT_CATALYST_CREATE, "menus_coll",
            context.scene.FLUENT_CATALYST_CREATE, "menus_index",
            rows=max(len(context.scene.FLUENT_CATALYST_CREATE.menus_coll), 4)
        )

        column = box.column()
        row = column.row(align=True)
        row.scale_y = 1.2
        row.operator(FLUENT_CATALYST_OT_ADD_MENU.bl_idname, text="Add sub-menu", icon="PRESET_NEW")

        row = layout.row()
        row.scale_y = 1.5
        row.operator(FLUENT_CATALYST_OT_PREVIOUS_STEP.bl_idname, text="Previous", icon="TRIA_LEFT")
        row.operator(FLUENT_CATALYST_OT_NEXT_STEP.bl_idname, text="Next", icon="TRIA_RIGHT")
