
def draw_callback_px(self, context):

    for item in self.ui_items_list:
        item.draw(self.events)
