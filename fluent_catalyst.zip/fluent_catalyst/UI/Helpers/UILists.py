import bpy

from ...operators import FLUENT_CATALYST_OT_REMOVE_MENU, FLUENT_CATALYST_OT_REMOVE_LIBRARY


class InputsUIList(bpy.types.UIList):
    bl_idname = "FLUENT_CATALYST_UL_inputs"

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        show_icon = "HIDE_OFF" if item.show else "HIDE_ON"
        row = layout.row()
        split = row.split(factor=0.5)
        r = split.row()
        r.active = item.show
        r.enabled = item.show
        r.prop(item, "name", text="", emboss=False)

        rs = split.split(factor=0.5)
        rs.enabled = item.show
        rs.prop(item, "type", text="")
        rs.prop(item, "menu", text="")

        row.prop(item, "show", text="", icon=show_icon, emboss=False)


class MenusUIList(bpy.types.UIList):
    bl_idname = "FLUENT_CATALYST_UL_menus"

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row()
        split = row.split(factor=0.5)
        r = split.row()

        if item.name == 'MENU_MAIN':
            r.active = False
            r.enabled = False

        r.prop(item, "name", text="", emboss=False)

        if item.name != "MENU_MAIN":
            rs = split.split(factor=0.5)
            rs.prop(item, "parent", text="")
            row.operator(
                FLUENT_CATALYST_OT_REMOVE_MENU.bl_idname,
                text="",
                icon="TRASH",
                emboss=False
            ).index_to_delete = index


class AssetsLibrariesUIList(bpy.types.UIList):
    bl_idname = "FLUENT_CATALYST_UL_assets_libraries"

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        show_icon = "HIDE_OFF" if item.show else "HIDE_ON"
        row = layout.row()
        split = row.split(factor=0.5)
        r = split.row()
        r.active = item.show
        r.enabled = item.show
        r.label(text=item.name)
        row.prop(item, "show", text="", icon=show_icon, emboss=False)
        row.operator(
            FLUENT_CATALYST_OT_REMOVE_LIBRARY.bl_idname,
            text="",
            icon="TRASH",
            emboss=False
        ).index_to_delete = index
