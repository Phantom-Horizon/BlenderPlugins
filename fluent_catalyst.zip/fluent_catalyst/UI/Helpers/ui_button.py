from mathutils import Vector
from .shapes import *
from ..icons import *


def make_button(what, align_left=False):
    if what == 'CANCEL':
        button = FLUENT_CATALYST_Ui_Button('CANCEL')
        button.set_text('Cancel')
        button.set_tool_tip('Cancel (ESC)')
        button.set_shape('RECTANGLE')
        button.set_icon('cancel')
        button.set_action('CANCELLED')
        overlap = bpy.context.preferences.system.use_region_overlap
        n_panel_width = 0
        if overlap:
            for region in bpy.context.area.regions:
                if region.type == 'UI':
                    n_panel_width = region.width
        button_dimensions = button.get_dimensions()[0]
        button.set_position((bpy.context.area.width - n_panel_width - button_dimensions, button_dimensions))

        return button
    elif what == 'QUIT':
        button = FLUENT_CATALYST_Ui_Button('QUIT')
        button.set_text('Quit')
        button.set_tool_tip('Valid and quit (RMB)')
        button.set_shape('RECTANGLE')
        button.set_action('FINISHED')
        button.set_icon('quit')

        return button
    elif what == 'BACK':
        button = FLUENT_CATALYST_Ui_Button('BACK')
        button.set_text('Back')
        button.set_icon('back_menu')

        if align_left:
            button.set_shape('RECTANGLE')
            button.set_action('BACK_MENU')
            button.set_align('LEFT')
            button.set_vertical_align('CENTER')
            button.set_text_size(get_addon_preferences().font_size)

            return button

        button.set_tool_tip('Back')
        button.set_shape('RECTANGLE')
        button.set_action('BACK_MENU')

        return button

    return None


class FLUENT_CATALYST_Ui_Button:
    def __init__(self, name=None):
        self.position = (0, 0)
        self.align = 'CENTER'
        self.vertical_align = 'NONE'
        self.dimensions = [100, 100]
        self.margin = 12
        self.default_bg_color = get_addon_preferences().bg_color
        self.hover_bg_color = get_addon_preferences().highlight_text
        self.active_bg_color = get_addon_preferences().active_bg_color
        self.show = True

        self.shape = 'RECTANGLE'

        self.id = name

        self.text = 'Button'
        self.text_size = 10
        self.text_color = (1.0, 1.0, 1.0, 1.0)
        self.text_position = []

        self.input_name = None
        self.input_min = None
        self.input_max = None

        self.icon = None
        self.icon_size = [32, 32]

        self.state = 0  # 1→hover 2→press
        self.is_active = False

        self.action = None

        self.tool_tip_text = ''
        self.tool_tip_text_dimensions = 0
        self.display_tool_tip = False

        self.parent_menu = None

    def set_align(self, a):
        self.align = a

    def get_align(self):
        return self.align

    def set_vertical_align(self, a):
        self.vertical_align = a

    def get_vertical_align(self):
        return self.vertical_align

    def set_margin(self, a):
        self.margin = a

    def get_margin(self):
        return self.margin

    def set_text_size(self, a):
        self.text_size = a
        self.refresh_size()

    def get_text_size(self):
        return self.text_size

    def get_id(self):
        return self.id

    def set_parent_menu(self, a):
        self.parent_menu = a

    def get_parent_menu(self):
        return self.parent_menu

    def set_tool_tip(self, string):
        self.tool_tip_text = string
        blf.size(0, self.text_size, 72)
        self.tool_tip_text_dimensions = blf.dimensions(0, string)

    def get_tool_tip(self):
        return self.tool_tip_text

    def set_default_color(self, color):
        self.default_bg_color = color

    def set_icon(self, image_name):
        icons, gl_images = load_icons()
        self.icon = gl_images[image_name].bindcode
        self.refresh_size()

    def set_show(self, value):
        self.show = value

    def refresh_size(self):
        if self.text == '' and self.icon:
            self.dimensions = [self.icon_size[0] + self.margin * 2, self.icon_size[1] + self.margin * 2]
        elif self.text and not self.icon:
            blf.size(0, self.text_size, 72)
            text_dimensions = blf.dimensions(0, self.text)
            self.dimensions = [text_dimensions[0] + self.margin * 2, text_dimensions[1] + self.margin * 2]
        elif not self.text and not self.icon:
            self.dimensions = [32, 32]
        elif self.text and self.icon:
            blf.size(0, self.text_size, 72)
            text_dimensions = blf.dimensions(0, self.text)
            self.icon_size = [text_dimensions[1]*1.4, text_dimensions[1]*1.4]
            self.dimensions = [self.icon_size[0]+text_dimensions[0] + self.margin * 2, text_dimensions[1] + self.margin * 2]

    def set_shape(self, shape):
        self.shape = shape
        if shape == 'CIRCLE':
            self.dimensions[1] = self.dimensions[0]

    def set_action(self, action):
        self.action = action

    def get_action(self):
        return self.action

    def set_text(self, text):
        self.text = text
        self.refresh_size()

    def get_text(self):
        return self.text

    def set_input_name(self, input_name):
        self.input_name = input_name

    def get_input_name(self):
        return self.input_name

    def set_input_min(self, input_min):
        self.input_min = input_min

    def get_input_min(self):
        return self.input_min

    def set_input_max(self, input_max):
        self.input_max = input_max

    def get_input_max(self):
        return self.input_max

    def set_text_position(self, position):
        self.text_position = position

    def set_position(self, pos):
        self.position = pos

    def get_position(self):
        return self.position

    def set_colors(self):
        color = self.default_bg_color

        # hover
        if self.state == 1:
            color = self.hover_bg_color

        # press, active
        elif self.state in [2, 3]:
            color = self.active_bg_color

        if self.is_active:
            color = self.hover_bg_color

        return color

    def outline_color(self):
        color = self.set_colors()
        R = color[0] * 1.3
        if R>1:
            R=1
        V = color[1] * 1.3
        if V > 1:
            V = 1
        B = color[2] * 1.3
        if B > 1:
            B = 1
        return(R, V, B, 1)

    def set_state(self, a):
        self.state = a

    def get_state(self):
        return self.state

    def set_active(self, a):
        self.is_active = a

    def get_active(self):
        return self.is_active

    def set_dimensions(self, d):
        self.dimensions = d

    def get_dimensions(self):
        return self.dimensions

    def draw(self, events):
        if self.show:
            self.is_hover(events)
            if self.shape == 'RECTANGLE':
                if self.state in [1, 2, 3]:
                    draw_rounded_rectangle(x=self.position[0], y=self.position[1], width=self.dimensions[0], height=self.dimensions[1], color=self.outline_color(), align=self.align, radius=5, resolution=6)
                    draw_rounded_rectangle(x=self.position[0]+2, y=self.position[1]-2, width=self.dimensions[0]-4, height=self.dimensions[1]-4, color=self.set_colors(), align=self.align, radius=4, resolution=6)
                else:
                    draw_rounded_rectangle(x=self.position[0], y=self.position[1], width=self.dimensions[0],
                                           height=self.dimensions[1], color=self.set_colors(), align=self.align, radius=5,
                                           resolution=6)
            elif self.shape == 'CIRCLE':
                draw_circle_full(cx=self.position[0], cy=self.position[1], r=self.dimensions[0] / 2,
                                 color=self.set_colors(), segments=64)
                draw_circle(cx=self.position[0], cy=self.position[1], r=self.dimensions[0] / 2, color=self.set_colors(),
                            segments=64)

            text_position = self.position
            left_margin = 0

            if self.vertical_align == 'CENTER':
                text_position = [text_position[0], text_position[1] - self.dimensions[1] / 2]
                left_margin = int(self.text_size/2)

            if self.icon:
                if self.shape == 'RECTANGLE':
                    draw_image(image_bindcode = self.icon, position = [self.position[0] + self.margin, self.position[1]- self.icon_size[0] - ((self.dimensions[1] - self.icon_size[0]) / 2)], size = self.icon_size)
                    text_position[0] = text_position[0] + self.icon_size[0] + self.margin
                else:
                    draw_image(image_bindcode=self.icon, position=[self.position[0]-self.icon_size[0]/2, self.position[1]-self.icon_size[1]/2], size=self.icon_size)

            draw_text(text=self.text, text_pos=text_position, text_size=self.text_size, text_color=self.text_color,
                      align=self.align, vertical_align=self.vertical_align, left_margin=left_margin)

            if self.display_tool_tip and self.tool_tip_text:
                if not self.text_position:
                    draw_text(text=self.tool_tip_text, text_pos=[self.position[0],
                                                                 self.position[1] + self.dimensions[1] / 2 +
                                                                 self.tool_tip_text_dimensions[1]+self.margin],
                              text_size=self.text_size, text_color=self.text_color, align=self.align)
                else:
                    draw_text(text=self.tool_tip_text, text_pos=[self.text_position[0], self.text_position[1]],
                              text_size=self.text_size, text_color=self.text_color, align=self.align)

    def is_hover(self, events):
        if self.show:
            x_min = self.position[0] - self.dimensions[0] / 2
            x_max = self.position[0] + self.dimensions[0] / 2
            y_min = self.position[1] - self.dimensions[1] / 2
            y_max = self.position[1] + self.dimensions[1] / 2

            if self.align == 'LEFT':
                x_min = self.position[0]
                x_max = self.position[0] + self.dimensions[0]
                y_min = self.position[1] - self.dimensions[1]
                y_max = self.position[1]

            if self.parent_menu:
                pie_center = self.parent_menu.get_pie_center()
                if pie_center == [0, 0]:
                    pie_center = [events['mouse_x'], events['mouse_y']]
                vec = Vector((events['mouse_x'] - pie_center[0], events['mouse_y'] - pie_center[1], 0))
                if vec.length > 32:
                    vec_2 = vec.normalized()
                    vec_2 = vec_2 * self.parent_menu.get_rayon_du_pie()
                    events['mouse_x'] = pie_center[0] + vec_2.x
                    events['mouse_y'] = pie_center[1] + vec_2.y
            if x_min < events['mouse_x'] < x_max and y_min < events['mouse_y'] < y_max:
                self.state = 1
                self.display_tool_tip = True
                if events['value'] == 'PRESS' and events['type'] == 'LEFTMOUSE':
                    self.state = 2
            else:
                self.display_tool_tip = False
                self.state = 0
        else:
            self.state = 0


class FLUENT_CATALYST_Ui_Layout:
    def __init__(self, id, title='', subtitle=''):
        self.id = id
        self.title = title
        self.subtitle = subtitle
        self.title_dim = blf.dimensions(0, title)
        self.subtitle_dim = blf.dimensions(0, subtitle)
        self.layout = 'ROW'
        self.button_list = []
        self.position = ['BOTTOM', 'CENTER']
        self.margin = 16
        if int(get_addon_preferences().icon_size) == 32:
            self.rayon_du_pie = 150
        else:
            self.rayon_du_pie = 225
        self.nombre_de_partie_du_pie = 1
        self.decalage = 0
        self.pie_center = [0, 0]
        self.column_layout_width = 0

        self.obj = None
        self.has_overlay = False
        self.overlay_margin = 12

    def set_pie_center(self, a):
        self.pie_center = a

    def get_pie_center(self):
        return self.pie_center

    def set_margin(self, a):
        self.margin = a

    def get_margin(self):
        return self.margin

    def set_decalage(self, a):
        self.decalage = a

    def get_id(self):
        return self.id

    def add_item(self, item):
        if self.layout == 'PIE':
            item.set_parent_menu(self)
        self.button_list.append(item)

    def remove_item(self, item):
        for i, b in enumerate(self.button_list):
            if type(b) is FLUENT_CATALYST_Ui_Button and b.get_id() == item:
                self.button_list.pop(i)
                break

    def get_items(self):
        return [b for b in self.button_list if b != 'SEPARATOR']

    def set_obj(self, obj):
        self.obj = obj

    def get_obj(self):
        return self.obj

    def add_separator(self):
        self.button_list.append('SEPARATOR')

    def set_rayon_du_pie(self, rayon):
        self.rayon_du_pie = rayon

    def get_rayon_du_pie(self):
        return self.rayon_du_pie

    def set_layout(self, layout):
        self.layout = layout

    def get_layout(self):
        return self.layout

    def set_has_overlay(self, a):
        self.has_overlay = a

    def get_has_overlay(self):
        return self.has_overlay

    def get_column_layout_width(self):
        return self.column_layout_width

    def spread(self, mouse_x=0, mouse_y=0):
        if self.layout == 'ROW':
            self.row_layout()
        if self.layout == 'COLUMN_LEFT':
            self.column_left_layout()
        elif self.layout == 'PIE':
            self.pie_layout(mouse_x, mouse_y)
        elif self.layout == 'COLUMN':
            self.column_layout(mouse_x, mouse_y)

    def column_layout(self, mouse_x, mouse_y):
        overlap = bpy.context.preferences.system.use_region_overlap
        t_panel_width = 0
        n_panel_width = 0
        if overlap:
            for region in bpy.context.area.regions:
                if region.type == 'TOOLS':
                    t_panel_width = region.width
                if region.type == 'UI':
                    n_panel_width = region.width
        largeur_fenetre = bpy.context.area.width - t_panel_width - n_panel_width
        hauteur_fenetre = bpy.context.area.height
        pos_x = mouse_x
        start_pos_y = mouse_y
        pos_y = start_pos_y
        menu_width = 0
        self.pie_center = [mouse_x, mouse_y]
        for index, b in enumerate(self.button_list):
            if b.get_dimensions()[0] > menu_width:
                menu_width = b.get_dimensions()[0]

            if index == 0:
                b.set_position([pos_x, start_pos_y])
                pos_y -= b.get_dimensions()[1] + self.margin
            else:
                b.set_position([pos_x, pos_y])
                pos_y -= b.get_dimensions()[1] + self.margin
        for index, b in enumerate(self.button_list):
            b.set_dimensions([menu_width, b.get_dimensions()[1]])
        self.column_layout_width = menu_width

    def pie_layout(self, mouse_x, mouse_y):
        nombre_de_boutton = len(self.button_list)
        if nombre_de_boutton:
            angle = math.radians(360 / nombre_de_boutton)
        else:
            angle = 0
        for index, b in enumerate(self.button_list):
            try:
                b.set_position([mouse_x + self.rayon_du_pie * math.cos(angle * index + self.decalage * angle),
                                mouse_y + self.rayon_du_pie * math.sin(angle * index + self.decalage * angle)])
                b.set_text_position([mouse_x, mouse_y])
            except:
                pass
        self.pie_center = [mouse_x, mouse_y]

    def column_left_layout(self):
        hauteur_total = 0
        for b in self.button_list:
            hauteur_total += b.get_dimensions()[1]
        hauteur_total += self.margin * (len(self.button_list) - 1)
        overlap = bpy.context.preferences.system.use_region_overlap
        t_panel_width = 0
        n_panel_width = 0
        if overlap:
            for region in bpy.context.area.regions:
                if region.type == 'TOOLS':
                    t_panel_width = region.width
                if region.type == 'UI':
                    n_panel_width = region.width
        largeur_fenetre = bpy.context.area.width - t_panel_width - n_panel_width
        hauteur_fenetre = bpy.context.area.height
        pos_x = (largeur_fenetre - self.button_list[0].get_dimensions()[0] - 64)
        start_pos_y = (hauteur_fenetre + hauteur_total) / 2
        pos_y = start_pos_y
        for index, b in enumerate(self.button_list):
            if index == 0:
                b.set_position([pos_x, start_pos_y])
                pos_y -= b.get_dimensions()[0] + self.margin
            else:
                b.set_position([pos_x, pos_y])
                pos_y -= b.get_dimensions()[0] + self.margin

    def row_layout(self):
        largeur_total = 0
        for b in self.button_list:
            largeur_total += b.get_dimensions()[0]
        largeur_total += self.margin * (len(self.button_list) - 1)
        t_panel_width = 0
        n_panel_width = 0
        overlap = bpy.context.preferences.system.use_region_overlap
        if overlap:
            for region in bpy.context.area.regions:
                if region.type == 'TOOLS':
                    t_panel_width = region.width
                if region.type == 'UI':
                    n_panel_width = region.width
        largeur_fenetre = bpy.context.area.width - t_panel_width - n_panel_width
        start_pos_x = (largeur_fenetre - largeur_total) / 2
        pos_x = start_pos_x
        for index, b in enumerate(self.button_list):
            if index == 0:
                b.set_position([start_pos_x, b.get_dimensions()[1]])
                pos_x += b.get_dimensions()[0] + self.margin
            else:
                b.set_position([pos_x, b.get_dimensions()[1]])
                pos_x += b.get_dimensions()[0] + self.margin

    def draw_overlay(self):
        layout_dim_x = layout_dim_y = 0
        for b in self.button_list:
            layout_dim_y += b.get_dimensions()[1] + self.margin

            if layout_dim_x < b.get_dimensions()[0]:
                layout_dim_x = b.get_dimensions()[0]

        draw_rounded_rectangle(
            self.pie_center[0] - self.overlay_margin,
            self.pie_center[1] + self.overlay_margin,
            layout_dim_x + 2 * self.overlay_margin,
            layout_dim_y + 2 * self.overlay_margin,
            get_addon_preferences().overlay_color,
            align='LEFT'
        )
        draw_rounded_rectangle(
            self.pie_center[0],
            self.pie_center[1],
            layout_dim_x,
            layout_dim_y,
            get_addon_preferences().bg_color,
            align='LEFT'
        )

    def draw(self, events):
        if self.layout == 'PIE' and events['mouse_left_click'] and not (
                bpy.context.active_object and bpy.context.active_object.mode == 'EDIT'):
            vec = Vector((events['mouse_x'] - self.pie_center[0], events['mouse_y'] - self.pie_center[1], 0))

            coords = [
                (self.pie_center[0] + vec.x, self.pie_center[1] + vec.y),
                (self.pie_center[0] + vec.x * 0.5, self.pie_center[1] + vec.y * 0.5)
            ]
            draw_circle_full(self.pie_center[0], self.pie_center[1], self.rayon_du_pie, (.5, .5, .5, .66), segments=64)
            draw_circle(self.pie_center[0], self.pie_center[1], self.rayon_du_pie, (1, 1, 1, 1), segments=64)
            draw_line(coords, thickness=2, color=(1, 1, 1, .5), is_2d=True)

            if self.title and not self.subtitle:
                draw_text(text=self.title, text_pos=(self.pie_center[0], self.pie_center[1]), text_size=16,
                          text_color=(1, 1, 1, 1), align='CENTER')
            if self.subtitle and not self.title:
                draw_text(text=self.subtitle, text_pos=(self.pie_center[0], self.pie_center[1]), text_size=16,
                          text_color=(1, 1, 1, 1), align='CENTER')
            if self.subtitle and self.title:
                draw_text(text=self.title, text_pos=(self.pie_center[0], self.pie_center[1] + self.title_dim[1] * 2),
                          text_size=16, text_color=(1, 1, 1, 0.5), align='CENTER')
                draw_text(text=self.subtitle,
                          text_pos=(self.pie_center[0], self.pie_center[1] - self.subtitle_dim[1] * 2), text_size=16,
                          text_color=(1, 1, 1, 0.5), align='CENTER')

        if self.layout == 'COLUMN' and events['show_menu'] \
            and not (bpy.context.active_object and bpy.context.active_object.mode == 'EDIT') \
                and self.has_overlay:
            self.draw_overlay()

        for b in self.button_list:
            if b != 'SEPARATOR':
                b.draw(events)
