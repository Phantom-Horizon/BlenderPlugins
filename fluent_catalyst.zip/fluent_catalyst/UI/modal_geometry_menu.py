import json

from bpy.props import StringProperty
from bpy_types import Operator
from .Helpers.shapes import FLUENT_Panel_Infos
from .Helpers.ui_button import FLUENT_CATALYST_Ui_Layout, FLUENT_CATALYST_Ui_Button, make_button
from .Helpers.viewport_drawing import draw_callback_px
from ..Tools.helper import *


class FLUENT_CATALYST_OT_GeometryMenu(Operator):
    """Edit a Fluent catalyst"""
    bl_idname = "fluentcatalyst.geometrymenu"
    bl_label = "Geometry node menu"
    bl_options = {'REGISTER', 'UNDO'}

    operation: StringProperty(
        default=''
    )

    ui_items_list = []
    events = None
    delay = None
    side_infos = None
    pie_menu_history = []
    pie_menus = {}
    action = None

    geo_modifier = None
    bevel_modifier = None
    original_bevel = None
    slider_origin_x = 0
    previous_value = 0
    original_value = 0
    status = 'NONE'
    enter_value = 'None'
    pressed_button = None
    active_object = None
    asset_name = ''

    show_menu = False

    @classmethod
    def poll(cls, context):
        if context.object and context.object.mode == 'OBJECT':
            return True
        else:
            return False

    def end(self):
        bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')

    def modal(self, context, event):
        self.ui_items_list = [i for i in self.ui_items_list if
                              not (type(i) is FLUENT_CATALYST_Ui_Layout and i.get_layout() in ['PIE', 'MIRROR', 'TAPER', 'COLUMN'])]
        try:
            self.ui_items_list.append(self.pie_menu_history[-1])
        except:
            pass

        context.area.tag_redraw()

        self.events = event_dico_refresh(self.events, event)

        self.active_object = bpy.context.active_object
        if self.status == 'NONE' and (pass_through(event) or event.type == 'TAB' or (self.active_object and self.active_object.mode == 'EDIT')):
            return {'PASS_THROUGH'}

        # action via les boutons
        action = None
        pressed_button = None
        for b in self.ui_items_list:
            if type(b) is FLUENT_CATALYST_Ui_Button:
                b.is_hover(self.events)
                if b.get_state() == 2:
                    action = b.get_action()
                    pressed_button = b
                    b.set_state(0)
                    break
                else:
                    action = None
            elif type(b) is FLUENT_CATALYST_Ui_Layout:
                layout_items_list = b.get_items()
                for i in layout_items_list:
                    i.is_hover(self.events)
                    if i.get_state() == 2:
                        action = i.get_action()
                        pressed_button = i
                        i.set_state(0)
                        break
                    else:
                        action = None
                if action:
                    break

        if event.value == 'PRESS' and event.type == 'LEFTMOUSE' \
                and not self.events['show_menu'] and not action and self.action not in ['REUSE', 'OBJECT']:
            action = 'DISPLAY_MENU'

        if action:
            self.events['show_menu'] = False
            if action == 'FINISHED':
                self.end()
                return {'FINISHED'}
            elif action in ['FLOAT', 'INTEGER', 'MATERIAL']:
                self.pie_menu_history.append(self.pie_menu_slider_validation())
                self.status = 'ADJUST#SLIDER'
                self.slider_origin_x = self.events['mouse_x']
                self.previous_value = self.original_value = self.geo_modifier[pressed_button.get_input_name()]
                self.original_bevel = self.bevel_modifier.width if self.bevel_modifier is not None else 0
                self.pressed_button = pressed_button
                if action == 'MATERIAL':
                    self.status = 'ADJUST#MATERIAL'
                    self.previous_value = self.original_value = get_index_for_material(
                        self.geo_modifier[pressed_button.get_input_name()]
                    )
            elif action == 'BOOLEAN':
                boolean_input = self.geo_modifier[pressed_button.get_input_name()]
                self.geo_modifier[pressed_button.get_input_name()] = not boolean_input
                refresh_gn_mods_and_children(self.active_object)
            elif 'MENU_' in action:
                self.events['show_menu'] = True
                sub_menu = self.pie_menus.get(action)
                current_menu = self.pie_menu_history[-1]
                sub_menu.spread(current_menu.get_pie_center()[0], current_menu.get_pie_center()[1])
                self.pie_menu_history.append(sub_menu)
            elif action == 'BACK_MENU':
                self.events['show_menu'] = True
                self.delay = None
                del self.pie_menu_history[-1]
            elif action == 'DISPLAY_MENU':
                self.events['show_menu'] = True
            elif action == 'VALIDATE':
                del self.pie_menu_history[-1]
                if 'ADJUST' in self.status:
                    self.status = 'NONE'

                self.show_default_side_info()
            elif action == 'RESET_ALL':
                self.remove_toolbar_by_name('TOOLS')
                self.show_reset_tool_menu()
            elif action in ['RESET', 'RESET_CANCEL']:
                if action == 'RESET':
                    reset_all_inputs(self.active_object, self.geo_modifier, self.bevel_modifier)
                self.remove_toolbar_by_name('RESET_TOOLS')
                self.show_default_tool_menu()

            elif action == 'REMOVE_ASSET':
                self.remove_asset()
                self.end()
                return {'FINISHED'}

            self.action = action
        else:
            self.delay = None

        if event.value == 'PRESS' and event.type == 'LEFTMOUSE' and self.events['show_menu'] and not action:
            self.events['show_menu'] = False

        if action == 'QUIT' or event.type == 'RIGHTMOUSE' and event.value == 'PRESS':
            self.end()
            return {'FINISHED'}

        if self.action == 'REUSE':
            self.side_infos.reset()
            self.side_infos.add_line('Pick another asset', 'Left click')
            self.side_infos.add_line('Cancel', 'ESC')

            if self.events['type'] == 'ESC' and self.events['value'] == 'PRESS':
                self.status = self.action = 'NONE'
                self.show_default_side_info()
        if self.action == 'REUSE' and self.events['mouse_left_click']:
            source_obj = None
            source_obj = click_on(event.mouse_region_x, event.mouse_region_y)
            if source_obj and source_obj.get('fluent_catalyst_name') is not None \
                    and source_obj.get('fluent_catalyst_name') == self.active_object.get('fluent_catalyst_name'):
                action = None
                copy_and_scale(self.active_object, source_obj)
                self.show_default_side_info()
                self.action = None

        if action == 'OBJECT':
            self.original_value = self.geo_modifier[pressed_button.get_input_name()]
            self.pressed_button = pressed_button
            current_object_name = 'None'
            if self.original_value is not None:
                current_object_name = self.original_value.name
            self.side_infos.reset()
            self.side_infos.add_line('Pick an object', 'Left click')
            self.side_infos.add_line('Current object', current_object_name)
            self.side_infos.add_line('Cancel', 'ESC')
        if self.action == 'OBJECT' and self.events['mouse_left_click']:
            source_obj = None
            source_obj = click_on(event.mouse_region_x, event.mouse_region_y)
            if source_obj and source_obj.get('fluent_catalyst_name') is None:
                action = None
                self.geo_modifier[self.pressed_button.get_input_name()] = source_obj
                refresh_gn_mods_and_children(self.active_object)
                self.show_default_side_info()
                self.action = None

        if 'ADJUST' in self.status and not self.events['show_menu']:
            callback, screen_text = self.adjustment()
            self.side_infos.reset()
            for i, j in enumerate(screen_text):
                self.side_infos.add_line(screen_text[i][0], screen_text[i][1])

        if 'callback' in locals() and 'STOP_ADJUSTMENT' in callback:
            self.show_default_side_info()
            del self.pie_menu_history[-1]
            self.status = 'NONE'
            self.pressed_button = None

            return {'RUNNING_MODAL'}

        # gestion affichage du pie menu
        if len(self.pie_menu_history) and self.events['show_menu']:
            for b in self.pie_menu_history[-1].get_items():
                try:
                    b.set_show(True)
                except:
                    print('--- ERROR Impossible to show button')
        else:
            if len(self.pie_menu_history) and self.pie_menu_history[-1].get_layout() not in ['MIRROR', 'TAPER']:
                self.pie_menu_history[-1].spread(self.events['mouse_x'], self.events['mouse_y'])
                for b in self.pie_menu_history[-1].get_items():
                    try:
                        b.set_show(False)
                    except:
                        print('--- ERROR Impossible to hide button')

        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        try:
            selected_asset = bpy.context.view_layer.objects.active
            lib_asset_name = selected_asset['fluent_catalyst_lib']
            self.asset_name = selected_asset['fluent_catalyst_name']
        except:
            make_oops(
                msg=["The selected object is not a Fluent Catalyst"],
                icon="ERROR",
                title="Wrong object"
            )
            return {'FINISHED'}

        self.events = event_dico_builder(event)
        self.side_infos = FLUENT_Panel_Infos()
        self.show_default_side_info()
        self.ui_items_list = []
        self.ui_items_list.append(self.side_infos)
        self.pie_menus = {}

        menu_json_file = os.path.join(
            get_addon_preferences().assets_libraries_path,
            lib_asset_name,
            self.asset_name,
            'fluent_menu.json'
        )
        if not os.path.isfile(menu_json_file):
            make_oops(
                msg=["Fluent menu file not found for this asset", "Please contact the creator"],
                icon="ERROR",
                title="Fail to create asset menu"
            )
            return {'FINISHED'}

        errors = self.generate_menus(context, menu_json_file, selected_asset)
        if len(errors):
            make_oops(
                msg=errors,
                icon="ERROR",
                title="Problem during menu creation"
            )
            return {'FINISHED'}

        self.pie_menu_history.append(self.pie_menus.get('MENU_MAIN'))
        
        args = (self, context)
        self._handle = bpy.types.SpaceView3D.draw_handler_add(draw_callback_px, args, 'WINDOW', 'POST_PIXEL')
        context.window_manager.modal_handler_add(self)

        return {'RUNNING_MODAL'}

    def generate_menus(self, context, menu_json_file, selected_asset):
        global BEVEL_MODIFIER

        with open(menu_json_file) as json_file:
            file_content = json.load(json_file)

            try:
                geo_name = file_content['GEOMETRY_NODE']
            except:
                return ['No "GEOMETRY_NODE" key found in the Fluent menu file', 'Please contact the creator']
            
            try:
                menu_list = file_content['MENU_LIST']
            except:
                return ['No "MENU_LIST" key found in the Fluent menu file', 'Please contact the creator']

            for mod in selected_asset.modifiers:
                if mod.type == 'NODES' and mod.node_group is not None and original_name(mod.node_group.name) == geo_name:
                    self.geo_modifier = mod
                    continue

                if mod.type == 'BEVEL' and BEVEL_MODIFIER in mod.name:
                    self.bevel_modifier = mod

            if self.geo_modifier is None:
                return ['Asset corrupted, no modifier with node "%s" found' % geo_name, 'Please contact the creator']
            
            for menu in menu_list:
                try:
                    menu_name = menu.get('name')
                    menu_inputs = file_content[menu_name]
                except:
                    self.pie_menus.clear()
                    return ['No menu inputs for menu "%s" found in the Fluent menu file' % menu.name, 'Please contact the creator']
                
                self.generate_menu(menu_inputs, menu_name)

            for menu in menu_list:
                if menu.get('parent') == '':
                    continue

                button = FLUENT_CATALYST_Ui_Button()
                button.set_text(menu.get('name'))
                button.set_icon('sub_menu')
                button.set_shape('RECTANGLE')
                button.set_action('MENU_' + menu.get('name'))
                button.set_align('LEFT')
                button.set_vertical_align('CENTER')
                button.set_text_size(get_addon_preferences().font_size)

                parent_name = 'MENU_MAIN' if menu.get('parent') == 'MENU_MAIN' else 'MENU_' + menu.get('parent')
                self.pie_menus.get(parent_name).add_item(button)

            for menu in menu_list:
                menu_key = 'MENU_' + menu.get('name')
                if menu.get('name') == 'MENU_MAIN' or menu_key in ['MENU_MAIN', 'VALIDATE']:
                    continue

                button = make_button('BACK', align_left=True)
                self.pie_menus.get(menu_key).add_item(button)

            self.show_default_tool_menu()

        return []

    def show_default_tool_menu(self):
        # Bottom toolbar
        row = FLUENT_CATALYST_Ui_Layout('TOOLS')
        # Reuse button
        button = FLUENT_CATALYST_Ui_Button()
        button.set_text('')
        button.set_tool_tip('Reuse properties')
        button.set_shape('CIRCLE')
        button.set_action('REUSE')
        button.set_icon('pick')
        button.set_align('CENTER')
        button.set_vertical_align('CENTER')
        button.set_text_size(get_addon_preferences().font_size)
        row.add_item(button)

        # Reset Default
        button = FLUENT_CATALYST_Ui_Button()
        button.set_text('')
        button.set_tool_tip('Reset to default values')
        button.set_shape('CIRCLE')
        button.set_icon('warning')
        button.set_action('RESET_ALL')
        button.set_align('CENTER')
        button.set_vertical_align('CENTER')
        button.set_text_size(get_addon_preferences().font_size)
        row.add_item(button)

        # Remove asset
        button = FLUENT_CATALYST_Ui_Button()
        button.set_text('')
        button.set_tool_tip('Remove asset')
        button.set_shape('CIRCLE')
        button.set_icon('corbeille')
        button.set_action('REMOVE_ASSET')
        button.set_align('CENTER')
        button.set_vertical_align('CENTER')
        button.set_text_size(get_addon_preferences().font_size)
        row.add_item(button)

        # Quit
        button = FLUENT_CATALYST_Ui_Button()
        button.set_text('')
        button.set_tool_tip('Quit')
        button.set_shape('CIRCLE')
        button.set_icon('quit')
        button.set_action('QUIT')
        button.set_align('CENTER')
        button.set_vertical_align('CENTER')
        button.set_text_size(get_addon_preferences().font_size)

        row.add_item(button)
        row.spread()

        self.ui_items_list.append(row)

    def show_reset_tool_menu(self):
        # Bottom toolbar
        row = FLUENT_CATALYST_Ui_Layout('RESET_TOOLS')
        # Confirm reset
        button = FLUENT_CATALYST_Ui_Button()
        button.set_text('')
        button.set_tool_tip('Confirm reset')
        button.set_shape('CIRCLE')
        button.set_action('RESET')
        button.set_icon('validate')
        button.set_align('CENTER')
        button.set_vertical_align('CENTER')
        button.set_text_size(get_addon_preferences().font_size)
        row.add_item(button)

        # Cancel reset
        button = FLUENT_CATALYST_Ui_Button()
        button.set_text('')
        button.set_tool_tip('Cancel reset')
        button.set_shape('CIRCLE')
        button.set_icon('cancel')
        button.set_action('RESET_CANCEL')
        button.set_align('CENTER')
        button.set_vertical_align('CENTER')
        button.set_text_size(get_addon_preferences().font_size)
        row.add_item(button)

        # Quit
        button = FLUENT_CATALYST_Ui_Button()
        button.set_text('')
        button.set_tool_tip('Quit')
        button.set_shape('CIRCLE')
        button.set_icon('quit')
        button.set_action('QUIT')
        button.set_align('CENTER')
        button.set_vertical_align('CENTER')
        button.set_text_size(get_addon_preferences().font_size)

        row.add_item(button)
        row.spread()

        self.ui_items_list.append(row)

    def generate_menu(self, menu_inputs,  menu_name, return_it=False):
        pie_menu = FLUENT_CATALYST_Ui_Layout(menu_name)
        pie_menu.set_layout('COLUMN')
        pie_menu.set_margin(0)
        pie_menu.set_has_overlay(True)
        
        for asset_input in menu_inputs:
            button = FLUENT_CATALYST_Ui_Button()
            button.set_text(asset_input.get('name'))
            button.set_input_name(asset_input.get('input_name'))
            button.set_shape('RECTANGLE')
            button.set_action(asset_input.get('type'))
            button.set_input_min(asset_input.get('min'))
            button.set_input_max(asset_input.get('max'))
            button.set_align('LEFT')
            button.set_vertical_align('CENTER')
            button.set_text_size(get_addon_preferences().font_size)
            pie_menu.add_item(button)

        if return_it:
            return pie_menu

        key_menu_name = 'MENU_MAIN' if menu_name == 'MENU_MAIN' else 'MENU_' + menu_name
        self.pie_menus.update({key_menu_name: pie_menu})

    def adjustment(self):
        what = self.status.split('#')[1]
        screen_text = []
        callback = []
        action = self.pressed_button.get_action()
        input_name = self.pressed_button.get_input_name()
        input_min = self.pressed_button.get_input_min()
        input_max = self.pressed_button.get_input_max()
        input_text = self.pressed_button.get_text()
        self.enter_value = enter_value(self.enter_value, self.events)

        if 'SLIDER' in what:
            increment = calculate_increment(self.events, input_min, input_max)

            if self.events['shift_press'] or self.events['shift_release'] or self.events['ctrl_press'] or self.events['ctrl_release']:
                self.slider_origin_x = self.events['mouse_x']
                self.previous_value = self.geo_modifier[input_name]

            input_value = self.previous_value + (self.events['mouse_x'] - self.slider_origin_x) / increment
            if input_min is not None and input_value < input_min:
                input_value = input_min
            if input_max is not None and input_value > input_max:
                input_value = input_max

            if action == 'INTEGER':
                input_value = int(input_value)

            update_bevel(
                input_text,
                input_name,
                input_value,
                self.geo_modifier,
                self.bevel_modifier,
                self.active_object
            )
            self.geo_modifier[input_name] = input_value

            if enter_value_validation(self.enter_value, self.events)[0]:
                update_bevel(
                    input_text,
                    input_name,
                    input_value,
                    self.geo_modifier,
                    self.bevel_modifier,
                    self.active_object
                )
                self.geo_modifier[input_name] = enter_value_validation(self.enter_value, self.events)[1]
                callback.append('STOP_ADJUSTMENT')
                self.enter_value = 'None'

            if self.events['type'] == 'ESC' and self.events['value'] == 'PRESS':
                update_bevel(
                    input_text,
                    input_name,
                    self.original_value,
                    self.geo_modifier,
                    self.bevel_modifier,
                    self.active_object
                )
                self.geo_modifier[input_name] = self.original_value

                self.status = 'NONE'
                del self.pie_menu_history[-1]

            # TEXT
            screen_text.append([
                input_text,
                adjustment_value(self.geo_modifier[input_name], self.enter_value)
            ])
        elif 'MATERIAL' in what:
            material_count = len(bpy.data.materials)
            if material_count == 0:
                screen_text.append([
                    input_text,
                    'ERROR : No materials in the scene'
                ])

                return callback, screen_text

            if not self.geo_modifier[input_name]:
                self.geo_modifier[input_name] = get_material_by_index(0)

            input_min = 0
            input_max = material_count - 1
            if input_max:
                increment = calculate_increment(self.events, input_min, input_max)
            else:
                increment = 1

            if self.events['shift_press'] or self.events['shift_release'] or self.events['ctrl_press'] or self.events['ctrl_release']:
                self.slider_origin_x = self.events['mouse_x']
                self.previous_value = get_index_for_material(self.geo_modifier[input_name])

            input_value = self.previous_value + (self.events['mouse_x'] - self.slider_origin_x) / increment
            if input_min is not None and input_value < input_min:
                input_value = input_min
            if input_max is not None and input_value > input_max:
                input_value = input_max

            self.geo_modifier[input_name] = get_material_by_index(int(input_value))

            if enter_value_validation(self.enter_value, self.events)[0]:
                self.geo_modifier[input_name] = get_material_by_index(
                    int(enter_value_validation(self.enter_value, self.events)[1])
                )
                callback.append('STOP_ADJUSTMENT')
                self.enter_value = 'None'

            if self.events['type'] == 'ESC' and self.events['value'] == 'PRESS':
                self.geo_modifier[input_name] = get_material_by_index(self.original_value)
                self.status = 'NONE'
                del self.pie_menu_history[-1]

            # TEXT
            index = 0
            for mat in bpy.data.materials:
                if index > 9:
                    screen_text.append([
                        'Too many materials to display',
                        'Use the slider'
                    ])
                    break

                screen_text.append([
                    '[' + str(index) + ']',
                    mat.name
                ])
                index += 1

            screen_text.append([
                input_text,
                adjustment_value_material(self.geo_modifier[input_name], self.enter_value)
            ])

        refresh_gn_mods_and_children(self.active_object)

        return callback, screen_text

    def pie_menu_slider_validation(self):
        menu_inputs = [{'name': 'Validate', 'input_name': 'validate', 'type': 'VALIDATE'}]

        return self.generate_menu(menu_inputs, 'VALIDATE', True)

    def show_default_side_info(self):
        self.side_infos.reset()
        self.side_infos.add_line(t1="Editing Fluent Catalyst", t2=self.asset_name)

    def remove_toolbar_by_name(self, name):
        for menu in self.ui_items_list:
            if not isinstance(menu, FLUENT_CATALYST_Ui_Layout) or menu.get_id() != name:
                continue

            self.ui_items_list.remove(menu)
            break

    def remove_asset(self):
        collections = self.active_object.users_collection
        for col in collections:
            if col.name == self.active_object.name:
                for o in col.objects:
                    bpy.data.objects.remove(o, do_unlink=True)
            bpy.data.collections.remove(col)
