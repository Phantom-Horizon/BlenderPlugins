import json
import shutil
import subprocess
import threading
import zipfile
import platform

from bpy.props import IntProperty, StringProperty
from bpy_extras.io_utils import ImportHelper
from bpy_types import Operator

from .Tools.helper import *


def update_menu(menu, menu_to_delete, menus_by_index, index_to_delete):
    if menu == menu_to_delete:
        return 'MENU_MAIN'

    current_menu_index = menus_by_index.get(menu)

    if current_menu_index is None or current_menu_index <= index_to_delete:
        return menu

    previous_menu = get_enum_value_by_index(bpy.context.scene.FLUENT_CATALYST_CREATE.menus_coll, current_menu_index - 1)

    return previous_menu.name


class FLUENT_CATALYST_OT_REMOVE_MENU(Operator):
    """Remove this menu"""
    bl_idname = "fluent_catalyst.remove_menu"
    bl_label = "Remove this menu"
    bl_options = {'REGISTER', 'UNDO'}
    index_to_delete: IntProperty()
    menu_to_delete = None

    def draw(self, context):
        layout = self.layout

        layout.label(text="This removes the menu \"%s\"" % self.menu_to_delete.name, icon="ERROR")
        layout.label(text="All the inputs using this menu will be assigned to \"MENU_MAIN\"")

    def invoke(self, context, event):
        self.menu_to_delete = get_enum_value_by_index(context.scene.FLUENT_CATALYST_CREATE.menus_coll,
                                                      self.index_to_delete)

        wm = context.window_manager
        return wm.invoke_props_dialog(self, width=400)

    def execute(self, context):
        fluent_catalyst_create = context.scene.FLUENT_CATALYST_CREATE

        menus_by_index = {}
        index = 0
        for menu in fluent_catalyst_create.menus_coll:
            menus_by_index.update({menu.name: index})
            index += 1

        for geo_input in fluent_catalyst_create.inputs_coll:
            geo_input.menu = update_menu(
                geo_input.menu,
                self.menu_to_delete,
                menus_by_index,
                self.index_to_delete
            )

        for menu in fluent_catalyst_create.menus_coll:
            if menu.name == 'MENU_MAIN' or menu.name == self.menu_to_delete.name:
                continue

            menu.parent = update_menu(
                menu.parent,
                self.menu_to_delete,
                menus_by_index,
                self.index_to_delete
            )

        fluent_catalyst_create.menus_coll.remove(self.index_to_delete)

        return {'FINISHED'}


class FLUENT_CATALYST_OT_NEXT_STEP(Operator):
    """Next step"""
    bl_idname = "fluent_catalyst.next_step"
    bl_label = "Next step"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return len(context.scene.FLUENT_CATALYST_CREATE.geometry_nodes_list)

    def execute(self, context):
        fluent_catalyst_create = context.scene.FLUENT_CATALYST_CREATE
        library = fluent_catalyst_create.assets_libraries
        asset = bpy.context.view_layer.objects.active.name
        asset_lib_dir = os.path.join(get_addon_preferences().assets_libraries_path, library, asset)

        if fluent_catalyst_create.create_step == 1 and os.path.isdir(asset_lib_dir):
            make_oops(
                msg=["This asset name \"%s\" already exists for this library" % asset],
                icon="ERROR",
                title="Asset already exists"
            )
            return {'FINISHED'}

        if fluent_catalyst_create.create_step == 1:
            init_inputs_from_selected_node()

            fluent_catalyst_create.menus_coll.clear()
            menu = fluent_catalyst_create.menus_coll.add()
            menu.name = 'MENU_MAIN'

        fluent_catalyst_create.create_step += 1

        return {'FINISHED'}


class FLUENT_CATALYST_OT_PREVIOUS_STEP(Operator):
    """Go back"""
    bl_idname = "fluent_catalyst.previous_step"
    bl_label = "Go back"
    bl_options = {'REGISTER', 'UNDO'}

    def draw(self, context):
        layout = self.layout

        layout.label(text="If you go back, you will lose all the menu configuration", icon="ERROR")

    def invoke(self, context, event):
        if context.scene.FLUENT_CATALYST_CREATE.create_step == 2:
            wm = context.window_manager
            return wm.invoke_props_dialog(self, width=400)

        self.execute(context)

        return {'FINISHED'}

    def execute(self, context):
        context.scene.FLUENT_CATALYST_CREATE.create_step -= 1
        context.scene.FLUENT_CATALYST_CREATE.in_creation = False
        context.scene.FLUENT_CATALYST_CREATE.creation_done = False
        context.scene.FLUENT_CATALYST_CREATE.error_preview = False
        context.scene.FLUENT_CATALYST_CREATE.creation_steps_done.clear()

        return {'FINISHED'}


class FLUENT_CATALYST_OT_GO_BACK_CREATION(Operator):
    """Go back"""
    bl_idname = "fluent_catalyst.go_back_creation"
    bl_label = "Go back to creation menu"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        context.scene.FLUENT_CATALYST_CREATE.create_step = 1
        context.scene.FLUENT_CATALYST_CREATE.creation_steps_done.clear()
        context.scene.FLUENT_CATALYST_CREATE.in_creation = False
        context.scene.FLUENT_CATALYST_CREATE.creation_done = False
        context.scene.FLUENT_CATALYST_CREATE.new_assets_library = ''
        context.scene.FLUENT_CATALYST_CREATE.geometry_nodes.clear()

        return {'FINISHED'}


class FLUENT_CATALYST_OT_REFRESH_INPUTS(Operator):
    """Refresh inputs"""
    bl_idname = "fluent_catalyst.refresh_inputs"
    bl_label = "Refresh inputs"
    bl_options = {'REGISTER', 'UNDO'}

    def draw(self, context):
        layout = self.layout
        layout.label(text="This will reset all the manual input types and menu changes you made", icon="ERROR")

    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self, width=450)

    def execute(self, context):
        init_inputs_from_selected_node()

        return {'FINISHED'}


class FLUENT_CATALYST_OT_ADD_LIBRARY(Operator):
    """Add to the library"""
    bl_idname = "fluent_catalyst.add_library"
    bl_label = "Add to the library"
    bl_options = {'REGISTER', 'UNDO'}

    _th = None

    def generate_menu_json_file(self, context, asset_lib_dir, fluent_catalyst_create):
        json_menu = dict()
        menus_list = list()
        for fluent_menu in fluent_catalyst_create.menus_coll:
            inputs_menu = list()
            for fluent_input in fluent_catalyst_create.inputs_coll:
                if not fluent_input.show or fluent_menu.name != fluent_input.menu:
                    continue

                inputs_menu.append(
                    {
                        "input_name": fluent_input.input_name,
                        "name": fluent_input.name,
                        "type": fluent_input.type,
                        "min": fluent_input.min,
                        "max": fluent_input.max
                    }
                )

            if len(inputs_menu) == 0:
                continue

            json_menu[fluent_menu.name] = inputs_menu

            parent_menu = fluent_menu.parent if fluent_menu.name != "MENU_MAIN" else ""
            menus_list.append({"name": fluent_menu.name, "parent": parent_menu})
        json_menu["MENU_LIST"] = menus_list
        json_menu["GEOMETRY_NODE"] = fluent_catalyst_create.geometry_nodes_list

        if not os.path.isdir(asset_lib_dir):
            os.mkdir(asset_lib_dir)
        json_file = open(asset_lib_dir + '/fluent_menu.json', 'w')
        json_file.write(json.dumps(json_menu, indent=4))
        json_file.close()
        tasks_queue.add_task((update_creation_step, (context, 'MENU')))

    def generate_blend_file(self, context, asset_lib_dir, library_name, asset_name):
        asset_object = bpy.context.view_layer.objects.active
        asset_object['fluent_catalyst_lib'] = library_name
        asset_object['fluent_catalyst_name'] = asset_name
        bpy.ops.scene.new(type='NEW')
        asset_scene = context.scene
        asset_scene.name = "Asset"

        asset_scene.collection.children.link(bpy.data.collections[asset_name])
        bpy.data.objects[asset_name].select_set(True)
        bpy.context.view_layer.objects.active = bpy.data.objects[asset_name]
        bpy.data.libraries.write(filepath=os.path.join(asset_lib_dir, "asset.blend"), datablocks={asset_scene},
                                 path_remap='RELATIVE_ALL')

        bpy.data.scenes.remove(asset_scene, do_unlink=True)
        update_creation_step(context, 'ASSET_FILE')

    def generate_preview(self, context, asset_lib_dir):
        script_file = os.path.dirname(os.path.realpath(__file__)) + '/external_render.py'
        asset_blend_file = bpy.data.filepath
        asset_object = bpy.context.view_layer.objects.active
        override_material = not bpy.context.scene.FLUENT_CATALYST_CREATE.use_asset_materials
        completed_process = subprocess.run(
            f'{bpy.app.binary_path} -b --factory-startup --python-exit-code 1 --python "{script_file}" -- --projectpath "{asset_blend_file}" --libdir "{asset_lib_dir}" --objectname "{asset_object.name}" --overridematerial "{override_material}"',
            shell=platform.system() != 'Windows'
        )

        if completed_process.returncode == 0:
            tasks_queue.add_task((update_creation_step, (context, 'PREVIEW')))
            return

        tasks_queue.add_task((update_error_preview, (context,)))

    def create_asset(self, context, fluent_catalyst_create, asset_lib_dir, library_name, asset_name):
        self.generate_menu_json_file(context, asset_lib_dir, fluent_catalyst_create)

        tasks_queue.add_task((self.generate_blend_file, (context, asset_lib_dir, library_name, asset_name)))

        self.generate_preview(context, asset_lib_dir)

        tasks_queue.add_task((init_libraries_previews, (True, True)))
        tasks_queue.add_task((refresh_selected_asset, ()))

    def execute(self, context):
        try:
            bpy.ops.wm.save_mainfile()
        except:
            make_oops(
                msg=["Please save your Blender file before creating an asset"],
                icon="ERROR",
                title="Save your Blender file"
            )
            return {'FINISHED'}

        fluent_catalyst_create = context.scene.FLUENT_CATALYST_CREATE
        library_name = fluent_catalyst_create.assets_libraries
        asset_name = bpy.context.view_layer.objects.active.name
        asset_lib_dir = os.path.join(get_addon_preferences().assets_libraries_path, library_name, asset_name)

        try:
            bpy.data.collections[asset_name]
            if bpy.context.view_layer.objects.active.users_collection[0].name != asset_name:
                raise Exception()
        except:
            make_oops(
                msg=["Your asset has to be in a collection with the same name \"%s\"" % asset_name],
                icon="ERROR",
                title="Wrong collection structure"
            )
            return {'FINISHED'}

        self._th = threading.Thread(
            target=self.create_asset,
            args=(context, fluent_catalyst_create, asset_lib_dir, library_name, asset_name)
        )

        fluent_catalyst_create.error_preview = False
        fluent_catalyst_create.in_creation = True
        fluent_catalyst_create.creation_done = False
        fluent_catalyst_create.create_step += 1
        fluent_catalyst_create.creation_steps_done.clear()

        self._th.start()

        return {'FINISHED'}


class FLUENT_CATALYST_OT_ADD_MENU(Operator):
    """Add a sub-menu"""
    bl_idname = "fluent_catalyst.add_menu"
    bl_label = "Add a sub-menu"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        menu = context.scene.FLUENT_CATALYST_CREATE.menus_coll.add()
        menu.name = 'Menu ' + str(len(context.scene.FLUENT_CATALYST_CREATE.menus_coll))

        return {'FINISHED'}


class FLUENT_CATALYST_OT_NEW_LIBRARY(Operator):
    """Create a new asset library"""
    bl_idname = "fluent_catalyst.new_library"
    bl_label = "Set up the Asset menu"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return len(context.scene.FLUENT_CATALYST_CREATE.new_assets_library)

    def execute(self, context):
        new_library = context.scene.FLUENT_CATALYST_CREATE.new_assets_library
        new_lib_dir = os.path.join(get_addon_preferences().assets_libraries_path, new_library)
        if os.path.isdir(new_lib_dir):
            make_oops(
                msg=["This library \"%s\" already exists" % new_library],
                icon="ERROR",
                title="Library already exists"
            )
            return {'FINISHED'}

        os.mkdir(new_lib_dir)
        new_lib = get_addon_preferences().assets_libraries.add()
        new_lib.name = new_library
        bpy.ops.wm.save_userpref()

        context.scene.FLUENT_CATALYST_CREATE.assets_libraries = new_library

        return {'FINISHED'}


class FLUENT_CATALYST_OT_IMPORT_ASSET(Operator):
    """Import asset"""
    bl_idname = "fluent_catalyst.import_asset"
    bl_label = "Import asset"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return not context.scene.FLUENT_CATALYST_CREATE.in_asset_deletion

    def copy_existing_settings(self, obj):
        fluent_catalyst_coll = bpy.data.collections['Fluent Catalyst']
        same_asset_colls = []
        for asset_coll in fluent_catalyst_coll.children:
            if original_name(asset_coll.name) == original_name(obj.name):
                same_asset_colls.append(asset_coll)

        if len(same_asset_colls) < 2:
            return

        latest_asset_coll = same_asset_colls[-2]
        obj_to_copy = None
        for asset_obj in latest_asset_coll.objects:
            if original_name(asset_obj.name) == original_name(obj.name):
                obj_to_copy = asset_obj
                break

        if obj_to_copy is None:
            return

        copy_and_scale(obj, obj_to_copy)

    def execute(self, context):
        global BEVEL_MODIFIER

        fluent_catalyst_create = context.scene.FLUENT_CATALYST_CREATE
        if not fluent_catalyst_create.asset_import_enabled:
            return {'FINISHED'}

        lib_full_name = "fa_libraries_%s" % fluent_catalyst_create.assets_libraries

        try:
            fluent_catalyst_coll = bpy.data.collections['Fluent Catalyst']
        except:
            fluent_catalyst_coll = bpy.data.collections.new('Fluent Catalyst')
            bpy.context.scene.collection.children.link(fluent_catalyst_coll)

        selected_asset = getattr(bpy.context.window_manager, lib_full_name)

        bpy.ops.object.select_all(action='DESELECT')
        asset_blend_file_path = get_addon_preferences().assets_libraries_path + '/' + fluent_catalyst_create.assets_libraries + '/' + selected_asset + '/asset.blend'
        asset_coll = append_element(asset_blend_file_path, 'collections', selected_asset, link=False, relative=False)
        fluent_catalyst_coll.children.link(asset_coll)

        bpy.context.scene.tool_settings.snap_elements = {'FACE'}
        bpy.context.scene.tool_settings.use_snap_align_rotation = True
        bpy.context.scene.tool_settings.snap_target = 'CENTER'

        # select main asset object
        for obj in asset_coll.objects:
            if original_name(obj.name) != selected_asset:
                continue

            obj.select_set(True)
            bpy.context.view_layer.objects.active = obj

            geo_mod = None
            bevel_mod = None
            for mod in obj.modifiers:
                if mod.type == 'NODES' and mod.node_group is not None:
                    geo_mod = mod
                    continue
                if mod.type == 'BEVEL' and BEVEL_MODIFIER in mod.name:
                    bevel_mod = mod

            reset_all_inputs(obj, geo_mod, bevel_mod)
            self.copy_existing_settings(obj)
            break

        bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

        return {'FINISHED'}


class FLUENT_CATALYST_OT_REMOVE_ASSET_TOGGLE(Operator):
    """Remove asset"""
    bl_idname = "fluent_catalyst.remove_asset_toggle"
    bl_label = "Remove asset"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        context.scene.FLUENT_CATALYST_CREATE.in_asset_deletion = not context.scene.FLUENT_CATALYST_CREATE.in_asset_deletion
        context.scene.FLUENT_CATALYST_CREATE.in_asset_deleted = False

        return {'FINISHED'}


class FLUENT_CATALYST_OT_REMOVE_ASSET(Operator):
    """Remove asset"""
    bl_idname = "fluent_catalyst.remove_asset"
    bl_label = "Remove asset"
    bl_options = {'REGISTER', 'UNDO'}

    def draw(self, context):
        lib_full_name = "fa_libraries_%s" % context.scene.FLUENT_CATALYST_CREATE.assets_libraries
        asset_name = getattr(bpy.context.window_manager, lib_full_name)

        layout = self.layout
        layout.label(text="Are you sure you want to remove the asset \"%s\" from the library" % asset_name, icon="ERROR")
        layout.label(text="This can't be undone!")

    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self, width=450)

    def execute(self, context):
        fluent_catalyst_create = context.scene.FLUENT_CATALYST_CREATE

        if not fluent_catalyst_create.in_asset_deletion:
            return {'FINISHED'}

        lib_full_name = "fa_libraries_%s" % fluent_catalyst_create.assets_libraries
        selected_asset = getattr(bpy.context.window_manager, lib_full_name)

        bpy.ops.object.select_all(action='DESELECT')
        lib_path = get_addon_preferences().assets_libraries_path + '/' + fluent_catalyst_create.assets_libraries
        asset_path = lib_path + '/' + selected_asset

        try:
            shutil.rmtree(asset_path)
        except OSError as e:
            print("Error: %s : %s" % (asset_path, e.strerror))

        init_libraries_previews(reload=True)
        refresh_selected_asset()

        return {'FINISHED'}


class FLUENT_CATALYST_OT_RELOAD_LIBRARIES(Operator):
    """Reload assets libraries"""
    bl_idname = "fluent_catalyst.reload_libraries"
    bl_label = "Reload assets libraries"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        init_libraries(reload=True)
        bpy.ops.wm.save_userpref()

        return {'FINISHED'}


class FLUENT_CATALYST_OT_IMPORT_LIBRARY(Operator, ImportHelper):
    """Import a library"""
    bl_idname = "fluent_catalyst.import_library"
    bl_label = "Import a library"
    bl_options = {'REGISTER', 'UNDO'}

    filter_glob: StringProperty(
        default='*.zip',
        options={'HIDDEN'}
    )

    def execute(self, context):
        dir, extension = os.path.splitext(self.filepath)
        lib_name = os.path.basename(dir)
        lib_path = get_addon_preferences().assets_libraries_path + '/' + lib_name

        if os.path.isdir(lib_path):
            print(lib_name)
            make_oops(
                msg=["This asset library \"%s\" is already installed or has the same name" % lib_name],
                icon="ERROR",
                title="Asset library already exists"
            )

            return {'FINISHED'}

        with zipfile.ZipFile(self.filepath, 'r') as zip_ref:
            zip_ref.extractall(get_addon_preferences().assets_libraries_path)

        init_libraries(reload=True)

        return {'FINISHED'}


class FLUENT_CATALYST_OT_REMOVE_LIBRARY(Operator):
    """Remove this library"""
    bl_idname = "fluent_catalyst.remove_library"
    bl_label = "Remove this library"
    bl_options = {'REGISTER', 'UNDO'}
    index_to_delete: IntProperty()
    library_to_delete = None

    def draw(self, context):
        layout = self.layout

        layout.label(text="This removes the library \"%s\"" % self.library_to_delete.name, icon="ERROR")
        layout.label(text="This action can not be undone")

    def invoke(self, context, event):
        self.library_to_delete = get_enum_value_by_index(get_addon_preferences().assets_libraries, self.index_to_delete)

        wm = context.window_manager
        return wm.invoke_props_dialog(self, width=400)

    def execute(self, context):
        fluent_catalyst_create = context.scene.FLUENT_CATALYST_CREATE
        lib_path = get_addon_preferences().assets_libraries_path + '/' + self.library_to_delete.name

        try:
            shutil.rmtree(lib_path)
        except OSError as e:
            print("Error: %s : %s" % (lib_path, e.strerror))

        get_addon_preferences().assets_libraries.remove(self.index_to_delete)

        return {'FINISHED'}

