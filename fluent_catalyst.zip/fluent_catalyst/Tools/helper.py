import os

import bpy
from bpy.props import EnumProperty
from bpy_extras import view3d_utils

from ..t3dn_bip import previews
from ..t3dn_bip.previews import ImagePreviewCollection
from .. import tasks_queue
from .constants import *

libraries_previews = []
GLOBAL_SCALE_INPUT = 'Global Scale'
BEVEL_MODIFIER = 'FC - Bevel'


def get_addon_preferences():
    addon_key = __package__.split(".")[0]
    addon_prefs = bpy.context.preferences.addons[addon_key].preferences

    return addon_prefs


def load_icons():
    raise Exception('Icons not implemented yet!')


def event_dico_builder(event):
    dico = {'mouse_left_click': False, 'mouse_x': event.mouse_region_x, 'mouse_y': event.mouse_region_y, 'value': None,
            'type': None, 'shift_press': False, 'shift_work': False, 'shift_release': False, 'ctrl_press': False,
            'ctrl_work': False, 'ctrl_release': False, 'alt_press': False, 'alt_work': False, 'alt_release': False, 'show_menu':False}

    return dico


def event_dico_refresh(dico, event):
    dico['mouse_x'] = event.mouse_region_x
    dico['mouse_y'] = event.mouse_region_y

    dico['value'] = event.value
    dico['type'] = event.type

    if event.shift and not dico['shift_press'] and not dico['shift_work']:
        dico['shift_press'] = True
    elif event.shift and dico['shift_press']:
        dico['shift_press'] = False
        dico['shift_work'] = True
    elif not event.shift and dico['shift_work']:
        dico['shift_release'] = True
        dico['shift_work'] = False
    elif not event.shift and dico['shift_release']:
        dico['shift_release'] = False
    else:
        dico['shift_press'] = False

    # gestion des événements du ctrl
    if event.ctrl and not dico['ctrl_press'] and not dico['ctrl_work']:
        dico['ctrl_press'] = True
    elif event.ctrl and dico['ctrl_press']:
        dico['ctrl_press'] = False
        dico['ctrl_work'] = True
    elif not event.ctrl and dico['ctrl_work']:
        dico['ctrl_release'] = True
        dico['ctrl_work'] = False
    elif not event.ctrl and dico['ctrl_release']:
        dico['ctrl_release'] = False
    else:
        dico['ctrl_press'] = False

    # gestion des événements du alt
    if event.alt and not dico['alt_press'] and not dico['alt_work']:
        dico['alt_press'] = True
    elif event.alt and dico['alt_press']:
        dico['alt_press'] = False
        dico['alt_work'] = True
    elif not event.alt and dico['alt_work']:
        dico['alt_release'] = True
        dico['alt_work'] = False
    elif not event.alt and dico['alt_release']:
        dico['alt_release'] = False
    else:
        dico['alt_press'] = False

    if event.value == 'PRESS' and event.type == 'LEFTMOUSE':
        dico['mouse_left_click'] = True

    if event.value == 'RELEASE' and event.type == 'LEFTMOUSE':
        dico['mouse_left_click'] = False

    return dico


def pass_through(event):
    return (event.type in viewport_navigation_events) \
           or (event.type in viewport_navigation_keys and not event.shift) \
           or (event.alt and event.type == 'LEFTMOUSE') \
           or (event.alt and event.type == 'RIGHTMOUSE')


def get_enum_value_by_index(enum, index):
    count = 0
    for item in enum:
        if count == index:
            return item

        count += 1

    return None


def init_default_library_path():
    fa_pref_path = get_addon_preferences().assets_libraries_path
    if fa_pref_path != '':
        return

    lib_path = os.path.dirname(os.path.realpath(__file__)).replace('Tools', 'Libraries')
    get_addon_preferences().assets_libraries_path = lib_path


def update_creation_step(context, step_name):
    context.scene.FLUENT_CATALYST_CREATE.creation_steps_done.append(step_name)


def update_error_preview(context):
    context.scene.FLUENT_CATALYST_CREATE.error_preview = True


def init_libraries(reload=False, dispatch_task=False):
    if len(get_addon_preferences().assets_libraries) > 0 and not reload:
        return

    get_addon_preferences().assets_libraries.clear()
    fa_pref_path = get_addon_preferences().assets_libraries_path

    if fa_pref_path == '':
        fa_pref_path = os.path.dirname(os.path.realpath(__file__))+'/../Libraries'

    for f in sorted(os.listdir(fa_pref_path)):
        lib_path = os.path.join(fa_pref_path, f)
        if os.path.isdir(lib_path):
            lib = get_addon_preferences().assets_libraries.add()
            lib.name = f

            if os.path.exists(os.path.join(lib_path, ".ishidden")):
                lib.show = False

    if dispatch_task:
        tasks_queue.add_task((update_creation_step, (bpy.context, 'LIB_LIST_REFRESHED')))


def init_geometry_nodes():
    bpy.context.scene.FLUENT_CATALYST_CREATE.geometry_nodes.clear()
    if bpy.context.active_object is None:
        return

    for mod in bpy.context.active_object.modifiers:
        if mod.type != 'NODES':
            continue

        bpy.context.scene.FLUENT_CATALYST_CREATE.geometry_nodes.append(mod)


def init_inputs_from_selected_node():
    fluent_catalyst_create = bpy.context.scene.FLUENT_CATALYST_CREATE
    selected_node = fluent_catalyst_create.geometry_nodes_list
    fluent_catalyst_create.inputs_coll.clear()

    for geo in fluent_catalyst_create.geometry_nodes:
        if geo.node_group is None or geo.node_group.name != selected_node:
            continue

        for node_input in geo.node_group.inputs:
            if node_input.name == 'Geometry':
                continue

            fluent_input = fluent_catalyst_create.inputs_coll.add()
            fluent_input.name = node_input.name
            fluent_input.input_name = node_input.identifier

            try:
                fluent_input.min = node_input.min_value
                fluent_input.max = node_input.max_value
            except:
                pass

            if node_input.type == 'VALUE':
                fluent_input.type = 'FLOAT'
            elif node_input.type == 'INT':
                fluent_input.type = 'INTEGER'
            elif node_input.type == 'BOOLEAN':
                fluent_input.type = 'BOOLEAN'
            elif node_input.type == 'MATERIAL':
                fluent_input.type = 'MATERIAL'
            elif node_input.type == 'OBJECT':
                fluent_input.type = 'OBJECT'


def make_oops(msg, title, icon):
    def oops(self, context):
        for m in msg:
            self.layout.label(text=m)

    bpy.context.window_manager.popup_menu(oops, title=title, icon=icon)


def append_element(filepath, collection, name, link, relative):
    if os.path.exists(filepath):

        with bpy.data.libraries.load(filepath, link=link, relative=relative) as (data_from, data_to):
            if name in getattr(data_from, collection):
                getattr(data_to, collection).append(name)

            else:
                print(f" WARNING: '{name}' does not exist in {filepath}/{collection}")
                return

        return getattr(data_to, collection)[0]

    else:
        print(f" WARNING: The file '{filepath}' does not exist")


def get_min_vertices(obj, axis):
    vmin = 10000
    for v in obj.data.vertices:
        if v.co.x < vmin and axis == 'x':
            vmin = v.co.x
            continue
        if v.co.y < vmin and axis == 'y':
            vmin = v.co.y
            continue
        if v.co.z < vmin and axis == 'z':
            vmin = v.co.z
            continue

    return vmin


def get_max_vertices(obj, axis):
    vmax = -10000
    for v in obj.data.vertices:
        if v.co.x > vmax and axis == 'x':
            vmax = v.co.x
            continue
        if v.co.y > vmax and axis == 'y':
            vmax = v.co.y
            continue
        if v.co.z > vmax and axis == 'z':
            vmax = v.co.z
            continue

    return vmax


def center_object_origin(obj):
    min_x = get_min_vertices(obj, 'x')
    min_y = get_min_vertices(obj, 'y')
    max_x = get_max_vertices(obj, 'x')
    max_y = get_max_vertices(obj, 'y')
    min_z = get_min_vertices(obj, 'z')

    x_origin = (min_x + max_x) / 2
    y_origin = (min_y + max_y) / 2

    bpy.context.scene.cursor.location = (x_origin, y_origin, min_z)
    bpy.ops.object.origin_set(type="ORIGIN_CURSOR")
    obj.location = (0, 0, 0)


def scale_to_max_dim(obj, max_x, max_y, max_z):
    dim_x = obj.dimensions[0]
    dim_y = obj.dimensions[1]
    dim_z = obj.dimensions[2]
    diff_x = dim_x - max_x
    diff_y = dim_y - max_y
    diff_z = dim_z - max_z
    custom_scale = 0

    if dim_x > max_x or dim_y > max_y or dim_z > max_z:
        if diff_x >= diff_y and diff_x >= diff_z:
            custom_scale = max_x / dim_x
        elif diff_y >= diff_x and diff_y >= diff_z:
            custom_scale = max_y / dim_y
        elif diff_z >= diff_x and diff_z >= diff_y:
            custom_scale = max_z / dim_z
    else:
        diff_x = abs(diff_x)
        diff_y = abs(diff_y)
        diff_z = abs(diff_z)
        if diff_x <= diff_y and diff_x <= diff_z:
            custom_scale = max_x / dim_x
        elif diff_y <= diff_x and diff_y <= diff_z:
            custom_scale = max_y / dim_y
        elif diff_z <= diff_x and diff_z <= diff_y:
            custom_scale = max_z / dim_z

    obj.scale = (custom_scale, custom_scale, custom_scale)

    return custom_scale


def insert_asset(self, context):
    fluent_catalyst_create = bpy.context.scene.FLUENT_CATALYST_CREATE
    if fluent_catalyst_create.in_asset_deleted:
        fluent_catalyst_create.in_asset_deleted = False

        return

    if fluent_catalyst_create.in_asset_deletion:
        bpy.ops.fluent_catalyst.remove_asset('INVOKE_DEFAULT')
    else:
        bpy.ops.fluent_catalyst.import_asset('INVOKE_DEFAULT')


def populate_preview_collection(col: ImagePreviewCollection, path, libname):
    libpath = os.path.join(path, libname)

    items = []

    folders = sorted(
        [(f, os.path.join(libpath, f)) for f in os.listdir(libpath) if os.path.isdir(os.path.join(libpath, f))],
        key=lambda x: x[0]
    )

    for asset_name, asset_path in folders:
        files = os.listdir(asset_path)

        if all([f in files for f in ["asset.blend", "preview.png"]]):
            icon_path = os.path.join(asset_path, "preview.png")
            preview = col.load_safe(asset_name, icon_path, 'IMAGE')

            items.append((asset_name, asset_name, "%s %s" % (libname, asset_name), preview.icon_id, preview.icon_id))

    return items


def init_libraries_previews(reload=False, dispatch_task=False):
    global libraries_previews

    fluent_catalyst_create = bpy.context.scene.FLUENT_CATALYST_CREATE
    fluent_catalyst_create.asset_import_enabled = False

    libname = fluent_catalyst_create.assets_libraries
    full_libname = "fa_libraries_" + libname
    if hasattr(bpy.types.WindowManager, full_libname) and not reload:
        fluent_catalyst_create.asset_import_enabled = True
        return

    col = previews.new(max_size=(256, 256))
    unregister_libs_previews(libname_to_unregister=libname)

    try:
        items = populate_preview_collection(
            col,
            get_addon_preferences().assets_libraries_path,
            libname
        )
    except:
        return

    enum = EnumProperty(items=items, update=insert_asset)
    setattr(bpy.types.WindowManager, full_libname, enum)
    libraries_previews.append((libname, col))

    if dispatch_task:
        tasks_queue.add_task((update_creation_step, (bpy.context, 'LIB_PREVIEW_REFRESHED')))

    fluent_catalyst_create.asset_import_enabled = True


def unregister_libs_previews(libname_to_unregister=None):
    global libraries_previews

    for libname, col in libraries_previews:
        if libname_to_unregister is not None and libname_to_unregister != libname:
            continue

        try:
            delattr(bpy.types.WindowManager, "fa_libraries_" + libname)
        except:
            pass

        try:
            previews.remove(col)
        except:
            pass


def is_selected_library_empty():
    if not hasattr(
        bpy.context.window_manager,
        "fa_libraries_%s" % bpy.context.scene.FLUENT_CATALYST_CREATE.assets_libraries
    ):
        return False

    return getattr(
        bpy.context.window_manager,
        "fa_libraries_%s" % bpy.context.scene.FLUENT_CATALYST_CREATE.assets_libraries
    ) == ''


def refresh_selected_asset():
    fluent_catalyst_create = bpy.context.scene.FLUENT_CATALYST_CREATE
    lib_path = get_addon_preferences().assets_libraries_path + '/' + fluent_catalyst_create.assets_libraries
    lib_full_name = "fa_libraries_%s" % fluent_catalyst_create.assets_libraries

    assets = [f for f in sorted(os.listdir(lib_path)) if os.path.isdir(os.path.join(lib_path, f))]

    fluent_catalyst_create.in_asset_deleted = True
    if len(assets) > 0:
        setattr(bpy.context.window_manager, lib_full_name, assets[-1])


def enter_value(value, event):
    # saisie des valeurs
    common_events = {'NUMPAD_MINUS': '-', 'MINUS': '-', 'NUMPAD_PERIOD': '.', 'PERIOD': '.', 'COMMA': '.',
                     'BACK_SPACE': "BACK_SPACE"}
    numpad_events = {'NUMPAD_0': '0', 'NUMPAD_1': '1', 'NUMPAD_2': '2', 'NUMPAD_3': '3', 'NUMPAD_4': '4',
                     'NUMPAD_5': '5', 'NUMPAD_6': '6', 'NUMPAD_7': '7', 'NUMPAD_8': '8', 'NUMPAD_9': '9'}
    normal_events = {'ZERO': '0', 'ONE': '1', 'TWO': '2', 'THREE': '3', 'FOUR': '4', 'FIVE': '5', 'SIX': '6',
                     'SEVEN': '7', 'EIGHT': '8', 'NINE': '9'}
    if bpy.context.preferences.inputs.use_emulate_numpad:
        # That way we do not override the camera switching hotkeys
        # BUG: For some reason, pressing 4 and 6 don't orbit...
        all_events = {**common_events, **numpad_events}
    else:
        all_events = {**common_events, **normal_events, **numpad_events}
    if event['value'] == 'PRESS' and event['type'] in all_events.keys():
        if value == 'None':
            value = ''
        valeur_to_append = all_events.get(event['type'], '')
        if valeur_to_append == 'BACK_SPACE':
            value = value[:-1]
        elif valeur_to_append == '-':
            # NOTE: It would be great to be able to negate the value without having to manually input everything
            #       Valeur is 'None' unfortunately, we need a new parameter or pass the real value
            #       Passing the real value is the best thing to do, we can clear it over here anyway!
            if len(value) > 0 and value[0] == '-':
                value = value[1:]
            else:
                value = '-' + value
        else:
            value += all_events.get(event['type'], '')

    return value


def enter_value_validation(value, event):
    try:
        if event['value'] == 'PRESS' and event['type'] in {'NUMPAD_ENTER', 'RET'}:
            return [True, float(value)]
        else:
            return [False]
    except:
        return [False]


def adjustment_value(modifier, enter_value):
    if enter_value == 'None':
        return str(round(modifier, 3))
    else:
        return enter_value


def adjustment_value_material(material, enter_value):
    if enter_value == 'None':
        return material.name
    elif enter_value == '':
        return ''
    else:
        selected_material = get_material_by_index(int(enter_value))
        if selected_material is not None:
            return selected_material.name

        return 'Please enter a correct material index'


def calculate_increment(events, input_min, input_max):
    # setting a default increment
    if events['shift_work']:
        increment = 12000
    elif events['ctrl_work']:
        increment = 120
    else:
        increment = 1200

    # Float max cap
    if input_min == -3.4028234663852886e+38 or input_max == 3.4028234663852886e+38:
        return increment

    # Int max cap
    if input_min == -2147483648.0 or input_max == 2147483648.0:
        return increment

    overlap = bpy.context.preferences.system.use_region_overlap
    t_panel_width = 0
    n_panel_width = 0
    if overlap:
        for region in bpy.context.area.regions:
            if region.type == 'TOOLS':
                t_panel_width = region.width
            if region.type == 'UI':
                n_panel_width = region.width

    available_width = (bpy.context.area.width - t_panel_width - n_panel_width) / 2

    input_value_diff = input_max - input_min
    increment = available_width / input_value_diff

    if events['shift_work']:
        increment *= 10
    elif events['ctrl_work']:
        increment /= 10

    return increment


def refresh_gn_mods(obj):
    for mod in obj.modifiers:
        if mod.type != 'NODES':
            continue

        mod.show_viewport = False
        mod.show_viewport = True


def refresh_gn_mods_and_children(obj):
    refresh_gn_mods(obj)

    for child in obj.children:
        if child.type != 'MESH':
            continue
        refresh_gn_mods(child)


def original_name(name):
    return name.split('.')[0]


def get_material_by_index(index):
    count = 0
    for mat in bpy.data.materials:
        if count == index:
            return mat

        count += 1

    return None


def get_index_for_material(material):
    if not material:
        return 0
    count = 0
    for mat in bpy.data.materials:
        if mat.name == material.name:
            return count

        count += 1

    return None


def copy_gn_mod_inputs(original_mod, source_obj):
    global GLOBAL_SCALE_INPUT

    scale_diff = None
    for mod in source_obj.modifiers:
        if original_name(mod.name) != original_name(original_mod.name):
            continue

        for node_input in original_mod.node_group.inputs:
            if node_input.name == 'Geometry':
                continue

            new_value = mod[node_input.identifier]
            if scale_diff is None and node_input.name == GLOBAL_SCALE_INPUT:
                scale_diff = new_value / original_mod[node_input.identifier]

            original_mod[node_input.identifier] = new_value
        break

    return scale_diff


def copy_and_scale(obj, source_obj):
    global BEVEL_MODIFIER

    scale_diff = None
    for mod in obj.modifiers:
        if mod.type == 'NODES' and mod.node_group is not None:
            current_scale_diff = copy_gn_mod_inputs(mod, source_obj)
            if scale_diff is None:
                scale_diff = current_scale_diff
            continue

        if mod.type == 'BEVEL' and BEVEL_MODIFIER in mod.name:
            for source_mod in source_obj.modifiers:
                if BEVEL_MODIFIER in source_mod.name:
                    mod.width = source_mod.width
                    break

    if scale_diff is not None:
        for child in obj.children:
            for mod in child.modifiers:
                if mod.type == 'BEVEL' and BEVEL_MODIFIER in mod.name:
                    mod.width *= scale_diff

    obj.scale = source_obj.scale
    refresh_gn_mods_and_children(obj)


def obj_ray_cast(obj, mouse_x, mouse_y):
    # get the context arguments
    scene = bpy.context.scene
    region = bpy.context.region
    rv3d = bpy.context.region_data
    coord = (mouse_x, mouse_y)

    # get the ray from the viewport and mouse
    view_vector = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
    ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)

    ray_target = ray_origin + view_vector

    matrix = obj.matrix_world.copy()
    # get the ray relative to the object
    matrix_inv = matrix.inverted()
    ray_origin_obj = matrix_inv @ ray_origin
    ray_target_obj = matrix_inv @ ray_target
    ray_direction_obj = ray_target_obj - ray_origin_obj

    # cast the ray
    success, location, normal, face_index = obj.ray_cast(ray_origin_obj, ray_direction_obj)

    return {
        'success': success,
        'hit': location,
        'normal': normal,
        'face_index': face_index,
        'ray_origin': ray_origin,
        'obj': obj
    }


def click_on(mouse_x, mouse_y, ignore=False, search=['MESH'], ignore_display=['BOUNDS', 'WIRE']):
    best_length_squared = -1.0
    best_obj = None

    visible_list = bpy.context.visible_objects
    depsgraph = bpy.context.evaluated_depsgraph_get()

    for obj in visible_list:
        if obj.type in search and not obj.hide_get() and obj.display_type not in ignore_display and obj != ignore:
            try:
                eval_obj = obj.evaluated_get(depsgraph)
                result = obj_ray_cast(eval_obj, mouse_x, mouse_y)
            except:
                result = {'success': False}

            if result['success']:
                length_squared = (obj.matrix_world @ result['hit'] - result.get('ray_origin')).length_squared
                if best_obj is None or length_squared < best_length_squared:
                    best_length_squared = length_squared
                    best_obj = obj

    return best_obj


def update_children_bevel(diff, obj):
    global BEVEL_MODIFIER

    for child in obj.children:
        for mod in child.modifiers:
            if mod.name != BEVEL_MODIFIER:
                continue

            mod.width *= diff


def update_bevel(input_text, input_name, input_value, modifier, bevel_modifier, obj):
    global GLOBAL_SCALE_INPUT

    if input_text != GLOBAL_SCALE_INPUT:
        return

    diff = 0
    if modifier[input_name] != 0:
        diff = input_value / modifier[input_name]

    if bevel_modifier is not None:
        bevel_modifier.width *= diff

    update_children_bevel(diff, obj)


def reset_all_inputs(obj, modifier, bevel_modifier):
    global GLOBAL_SCALE_INPUT

    for fluent_input in modifier.node_group.inputs:
        if fluent_input.name == 'Geometry':
            continue

        if fluent_input.name == GLOBAL_SCALE_INPUT:
            diff = 0
            input_value = modifier[fluent_input.identifier]
            if input_value != 0:
                diff = fluent_input.default_value / input_value

            if bevel_modifier is not None:
                bevel_modifier.width *= diff

            update_children_bevel(diff, obj)

        modifier[fluent_input.identifier] = fluent_input.default_value

    refresh_gn_mods_and_children(obj)
