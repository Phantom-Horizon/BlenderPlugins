viewport_navigation_events = [
    'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE',
    'TRACKPADPAN', 'TRACKPADZOOM', 'MOUSEROTATE', 'MOUSESMARTZOOM',
    'NDOF_MOTION'
]

viewport_navigation_keys = ['NUMPAD_1', 'NUMPAD_2', 'NUMPAD_3', 'NUMPAD_5', 'NUMPAD_7']

free_key = ['TAB', 'G', 'R']