import os
import bpy


def append_element(filepath, collection, name, link, relative):
    if os.path.exists(filepath):

        with bpy.data.libraries.load(filepath, link=link, relative=relative) as (data_from, data_to):
            if name in getattr(data_from, collection):
                getattr(data_to, collection).append(name)

            else:
                print(f" WARNING: '{name}' does not exist in {filepath}/{collection}")
                return

        return getattr(data_to, collection)[0]

    else:
        print(f" WARNING: The file '{filepath}' does not exist")


def get_min_vertices(obj, axis):
    vmin = 10000
    for v in obj.data.vertices:
        if v.co.x < vmin and axis == 'x':
            vmin = v.co.x
            continue
        if v.co.y < vmin and axis == 'y':
            vmin = v.co.y
            continue
        if v.co.z < vmin and axis == 'z':
            vmin = v.co.z
            continue

    return vmin


def get_max_vertices(obj, axis):
    vmax = -10000
    for v in obj.data.vertices:
        if v.co.x > vmax and axis == 'x':
            vmax = v.co.x
            continue
        if v.co.y > vmax and axis == 'y':
            vmax = v.co.y
            continue
        if v.co.z > vmax and axis == 'z':
            vmax = v.co.z
            continue

    return vmax


def center_object_origin(obj):
    min_x = get_min_vertices(obj, 'x')
    min_y = get_min_vertices(obj, 'y')
    max_x = get_max_vertices(obj, 'x')
    max_y = get_max_vertices(obj, 'y')
    min_z = get_min_vertices(obj, 'z')

    x_origin = (min_x + max_x) / 2
    y_origin = (min_y + max_y) / 2

    bpy.context.scene.cursor.location = (x_origin, y_origin, min_z)
    bpy.ops.object.origin_set(type="ORIGIN_CURSOR")
    obj.location = (0, 0, 0)


def scale_to_max_dim(obj, max_x, max_y, max_z):
    dim_x = obj.dimensions[0]
    dim_y = obj.dimensions[1]
    dim_z = obj.dimensions[2]
    ratio_x = dim_x / max_x
    ratio_y = dim_y / max_y
    ratio_z = dim_z / max_z
    custom_scale = 0

    if ratio_x >= ratio_y and ratio_x >= ratio_z:
        custom_scale = max_x / dim_x
    elif ratio_y >= ratio_x and ratio_y >= ratio_z:
        custom_scale = max_y / dim_y
    elif ratio_z >= ratio_x and ratio_z >= ratio_y:
        custom_scale = max_z / dim_z

    obj.scale = (custom_scale, custom_scale, custom_scale)

    return custom_scale


def render_logic(save_path, asset_lib_dir, object_name, override_material):
    preview_scene = append_element(
        os.path.dirname(os.path.realpath(__file__)) + '/preview_scene.blend',
        'scenes',
        "RENDER_PREVIEW",
        link=False,
        relative=False
    )
    bpy.context.window.scene = preview_scene

    bpy.context.scene.render.engine = 'CYCLES'
    bpy.context.scene.cycles.samples = 150
    bpy.context.scene.render.resolution_x = 256
    bpy.context.scene.render.resolution_y = 256
    prefs = bpy.context.preferences
    cprefs = prefs.addons['cycles'].preferences
    for compute_device_type in ('CUDA', 'OPENCL', 'NONE'):
        try:
            cprefs.compute_device_type = compute_device_type
            break
        except TypeError:
            pass

    # Enable all CPU and GPU devices
    for device in cprefs.devices:
        device.use = True

    asset_coll = append_element(save_path, 'collections', object_name, link=False, relative=False)
    preview_scene.collection.children.link(asset_coll)

    preview_object = bpy.data.objects[object_name]
    preview_object.select_set(True)
    bpy.context.view_layer.objects.active = preview_object
    bpy.ops.object.convert(target='MESH')

    for child in preview_object.children:
        child.select_set(True)
        bpy.context.view_layer.objects.active = child
        bpy.ops.object.convert(target='MESH')
        child.select_set(False)

    bpy.context.view_layer.objects.active = preview_object
    preview_object.scale = (1, 1, 1)
    preview_object.rotation_euler = (0, 0, 0)
    preview_object.location = (0, 0, 0)
    center_object_origin(preview_object)
    scale_to_max_dim(preview_object, 0.78, 0.78, 0.50)

    mat = bpy.data.materials.get("ASSET")
    if override_material == 'True':
        for s in preview_object.material_slots:
            s.material = mat
        for child in preview_object.children:
            for s in child.material_slots:
                s.material = mat
    else:
        if preview_object.data.materials:
            if preview_object.data.materials[0] is None:
                preview_object.active_material_index = 0
                bpy.ops.object.material_slot_remove()

            if not preview_object.data.materials:
                preview_object.data.materials.append(mat)
        else:
            preview_object.data.materials.append(mat)

    preview_scene.render.filepath = os.path.join(asset_lib_dir, "preview.png")
    bpy.ops.render.render(write_still=True)


def main():
    import sys  # to get command line args
    import argparse  # to parse options for us and print a nice help message

    # get the args passed to blender after "--", all of which are ignored by
    # blender so scripts may receive their own arguments
    argv = sys.argv

    if "--" not in argv:
        argv = []  # as if no args are passed
    else:
        argv = argv[argv.index("--") + 1:]  # get all args after "--"

    # When --help or no args are given, print this help
    usage_text = (
            "Run blender in background mode with this script:"
            "  blender --background --python " + __file__ + " -- [options]"
    )

    parser = argparse.ArgumentParser(description=usage_text)

    parser.add_argument(
        "-s", "--projectpath", dest="save_path",
        help="Blender asset project",
    )
    parser.add_argument(
        "-l", "--libdir", dest="asset_lib_dir",
        help="Asset destination directory",
    )

    parser.add_argument(
        "-o", "--objectname", dest="object_name",
        help="Name of the object to append to the script",
    )

    parser.add_argument(
        "-m", "--overridematerial", dest="override_material",
        help="Override the asset material",
    )

    args = parser.parse_args(argv)  # In this example we won't use the args

    if not argv:
        parser.print_help()
        return

    # Run the render
    render_logic(args.save_path, args.asset_lib_dir, args.object_name, args.override_material)

    print("batch job finished, exiting")


if __name__ == "__main__":
    main()
