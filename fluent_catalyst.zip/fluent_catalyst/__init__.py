"""
Copyright (C) 2022
cgsebfr@gmail.com

Created by CG Thoughts and CG Seb

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

    Auto-load provided by Jacques Lucke <https://gist.github.com/JacquesLucke/11fecc6ea86ef36ea72f76ca547e795b>
"""
import bpy
from bpy.props import PointerProperty

from .Tools.helper import unregister_libs_previews, init_default_library_path
from .properties import CreateAssetSceneProperties
from . import auto_load
from . import tasks_queue

bl_info = {
    "name": "Fluent Catalyst",
    "description": "The only asset library you need",
    "author": "CG Thoughts, CG Seb",
    "version": (1, 0, 1),
    "blender": (3, 4, 0),
    "location": "View3D",
    "doc_url": "https://cgthoughts.com/fluent/catalyst/doc/",
    "category": "Object"}

auto_load.init()


def register():
    auto_load.register()
    tasks_queue.register()
    bpy.app.timers.register(tasks_queue.queue_worker)
    bpy.types.Scene.FLUENT_CATALYST_CREATE = PointerProperty(type=CreateAssetSceneProperties)

    init_default_library_path()


def unregister():
    auto_load.unregister()
    tasks_queue.unregister()
    bpy.app.timers.unregister(tasks_queue.queue_worker)

    unregister_libs_previews()


if __name__ == "__main__":
    register()
