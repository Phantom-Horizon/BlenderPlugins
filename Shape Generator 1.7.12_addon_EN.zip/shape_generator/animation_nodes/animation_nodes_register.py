from . import node_shape_generator

def register():
    '''Register Shape Generator Animation Nodes Classes'''
    from bpy.utils import register_class
    register_class(node_shape_generator.ShapeGeneratorNode)

def unregister():
    '''Unregister Shape Generator Animation Nodes Classes'''
    from bpy.utils import unregister_class
    unregister_class(node_shape_generator.ShapeGeneratorNode)
