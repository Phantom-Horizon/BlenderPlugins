import bpy
from bpy.props import EnumProperty, FloatVectorProperty, BoolProperty, IntProperty
import random
from animation_nodes.base_types import AnimationNode
import numpy as np
import math
import mathutils
from mathutils import Vector
import bmesh
from ..utils import generate
from ..utils import uvcalc_smart_project
if bpy.app.version < (2, 93, 0):
    from animation_nodes.data_structures import (
        Vector3DList, 
        Vector2DList, 
        EdgeIndicesList, 
        PolygonIndicesList, 
        Mesh
    )
else:
    from animation_nodes.data_structures import (
        Vector3DList, 
        Vector2DList, 
        EdgeIndicesList, 
        PolygonIndicesList, 
        Mesh,
        Attribute,
        AttributeType,
        AttributeDomain,
        AttributeDataType,
        VirtualVector2DList,
    )

class ShapeGeneratorNode(bpy.types.Node, AnimationNode):
    bl_idname = "an_ShapeGeneratorNode"
    bl_label = "Generate Shape"

    random_seed = 12345


    bevel_method : EnumProperty(
            name = "Width Method",
            description = "Declares how Width will be interpreted to determine the amount of bevel",
            default="OFFSET",
            items = [
                ("OFFSET" , "Offset" , "Amount is offset of new edges from original"),
                ("WIDTH", "Width", "Amount is width of new face"),
                ("DEPTH" , "Depth" , "Amount is perpendicular distance of original edge to bevel face"),
                ("PERCENT", "Percent", "Amount is percent of adjacent edge length")
            ]
        )


    favour_vec : FloatVectorProperty(
            name="Favour",
            description="Favour",
            subtype='XYZ',
            min=0,max=1,
            default=[1,1,1],
            )

    prevent_ovelapping_faces  : BoolProperty(
            name="Prevent face overlaps",
            description="Attempt to stop faces from overlapping one another",
            default=False
            )

    overlap_check_limit : IntProperty(
            name="Face check limit",
            description="Limit the number of checks the tool will do on other faces. Zero will mean the check will never stop.",
            default=0,
            min=0
            )

    def getVertexLocations(self, bMesh):
        return Vector3DList.fromValues(v.co for v in bMesh.verts)

    def getEdgeIndices(self, bMesh):
        return EdgeIndicesList.fromValues(tuple(v.index for v in edge.verts) for edge in bMesh.edges)

    def getPolygonIndices(self, bMesh):
        return PolygonIndicesList.fromValues(tuple(v.index for v in face.verts) for face in bMesh.faces)


    def create(self):

        self.newInput("Integer", "Amount", "amount", value = 10, minValue=0)
        self.newInput("Integer", "Random Seed", "random_seed", value = 12345)

        self.newInput("Float", "Min Extrude", "min_extrude", value=0.5, minValue=0)
        self.newInput("Float", "Max Extrude", "max_extrude", value=1, minValue=0)

        self.newInput("Float", "Min Taper", "min_taper", value=0.5, minValue=0)
        self.newInput("Float", "Max Taper", "max_taper", value = 1, minValue=0)

        self.newInput("Float", "Min Rotation", "min_rotation", value = 0)
        self.newInput("Float", "Max Rotation", "max_rotation", value = 20)

        self.newInput("Float", "Min Slide", "min_slide", value=0, minValue=0)
        self.newInput("Float", "Max Slide", "max_slide", value=0.1, minValue=0)

        self.newInput("Integer", "Subdivide Edges", "subdivide_edges", value = 0, minValue=0)

        self.newInput("Float", "UV Angle Limit", "uv_projection_limit", value=66.0, minValue=1, maxValue=89)
        self.newInput("Float", "UV Island Margin", "uv_island_margin", value=0.0, minValue=0, maxValue=1)
        self.newInput("Float", "UV Area Weight", "uv_area_weight", value=0.0, minValue=0, maxValue=1)
        self.newInput("Boolean", "UV Stretch to Bounds", "uv_stretch_to_bounds", value=True)
        self.newInput("Boolean", "Mirror X", "mirror_x", value=True)
        self.newInput("Boolean", "Mirror Y", "mirror_y", value=False)
        self.newInput("Boolean", "Mirror Z", "mirror_z", value=False)

        self.newInput("Vector", "Local Location", "location", value=(0,0,0))
        self.newInput("Euler", "Local Rotation", "rotation", value=(0,0,0))
        self.newInput("Vector", "Local Scale", "scale", value=(1,1,1))

        self.newOutput("Mesh", "Mesh", "mesh")


    def drawAdvanced(self, layout):

        col = layout.column()
        col.prop(self, "favour_vec", text="When choosing a face, favour")
        col.prop(self, "prevent_ovelapping_faces")
        check_limit_col = col.column()
        check_limit_col.enabled = self.prevent_ovelapping_faces
        check_limit_col.prop(self, "overlap_check_limit")

    def execute(self,
                amount,
                random_seed,
                min_extrude,
                max_extrude,
                min_taper,
                max_taper,
                min_rotation,
                max_rotation,
                min_slide,
                max_slide,
                subdivide_edges,
                uv_projection_limit,
                uv_island_margin,
                uv_area_weight,
                uv_stretch_to_bounds,
                mirror_x,
                mirror_y,
                mirror_z,
                location,
                rotation,
                scale
                ):

        random.seed(random_seed)

        mesh = generate.generate_shape_mesh(min_extrude = min_extrude,
                                    max_extrude = max_extrude,
                                    amount = amount,
                                    random = random,
                                    min_taper = min_taper,
                                    max_taper = max_taper,
                                    min_rotation = min_rotation,
                                    max_rotation = max_rotation,
                                    min_slide = min_slide,
                                    max_slide = max_slide,
                                    favour_vec = self.favour_vec,
                                    overlap_check_limit = self.overlap_check_limit,
                                    prevent_ovelapping_faces = self.prevent_ovelapping_faces,
                                    location = location,
                                    rotation = rotation,
                                    scale = scale,
                                    subdivide_edges = subdivide_edges
                                    )

        #apply mirror if necessary by first bisecting along the appropriate axis.
        if mirror_x or mirror_y or mirror_z:

            bm = bmesh.new()   # create an empty BMesh
            bm.from_mesh(mesh)   # fill it in from a Mesh
            if mirror_x:
                bmesh.ops.bisect_plane(bm, geom=bm.verts[:] + bm.edges[:] + bm.faces[:], plane_co=Vector((0,0,0)), plane_no=Vector((1,0,0)), clear_inner=True)
                bm.to_mesh(mesh)
                bm.free()
                mesh.update()
                bm = bmesh.new()   # create an empty BMesh
                bm.from_mesh(mesh)   # fill it in from a Mesh
                bmesh.ops.mirror(bm, geom=bm.verts[:] + bm.edges[:] + bm.faces[:], axis ='X', merge_dist=0.001)
                bmesh.ops.recalc_face_normals(bm, faces=bm.faces)

            if mirror_y:
                bmesh.ops.bisect_plane(bm, geom=bm.verts[:] + bm.edges[:] + bm.faces[:], plane_co=Vector((0,0,0)), plane_no=Vector((0,1,0)), clear_inner=True)
                bm.to_mesh(mesh)
                bm.free()
                mesh.update()
                bm = bmesh.new()   # create an empty BMesh
                bm.from_mesh(mesh)   # fill it in from a Mesh
                bmesh.ops.mirror(bm, geom=bm.verts[:] + bm.edges[:] + bm.faces[:], axis ='Y', merge_dist=0.001)
                bmesh.ops.recalc_face_normals(bm, faces=bm.faces)

            if mirror_z:
                bmesh.ops.bisect_plane(bm, geom=bm.verts[:] + bm.edges[:] + bm.faces[:], plane_co=Vector((0,0,0)), plane_no=Vector((0,0,1)), clear_inner=True)
                bm.to_mesh(mesh)
                bm.free()
                mesh.update()
                bm = bmesh.new()   # create an empty BMesh
                bm.from_mesh(mesh)   # fill it in from a Mesh
                bmesh.ops.mirror(bm, geom=bm.verts[:] + bm.edges[:] + bm.faces[:], axis ='Z', merge_dist=0.001)
                bmesh.ops.recalc_face_normals(bm, faces=bm.faces)


            bm.to_mesh(mesh)
            bm.free()
            mesh.update()


        bm = bmesh.new()   # create an empty BMesh
        bm.from_mesh(mesh)   # fill it in from a Mesh

        if bpy.app.version < (2, 90, 0):
            mesh_to_return = Mesh(vertices=self.getVertexLocations(bm), 
                                    edges=self.getEdgeIndices(bm), 
                                    polygons = self.getPolygonIndices(bm))
        else:
            mesh_to_return = Mesh(vertices=self.getVertexLocations(bm), 
                                    edges=self.getEdgeIndices(bm), 
                                    polygons = self.getPolygonIndices(bm),
                                    skipValidation = True)

        bm.to_mesh(mesh)
        bm.free()  # free and prevent further access

        # Add UV Coords
        uvcalc_smart_project.smart_project(mesh,
                                            projection_limit = uv_projection_limit,
                                            island_margin =uv_island_margin,
                                            user_area_weight = uv_area_weight,
                                            stretch_to_bounds = uv_stretch_to_bounds)

        positions = getUVMap(mesh, mesh.uv_layers[0])
        if hasattr(mesh_to_return, "insertUVMap"):
            mesh_to_return.insertUVMap("UVMap", getUVMap(mesh, mesh.uv_layers[0]))
        elif hasattr(mesh_to_return, "insertUVMapAttribute"):
            mesh_to_return.insertUVMapAttribute(Attribute("UVMap", AttributeType.UV_MAP, AttributeDomain.CORNER, 
                                                    AttributeDataType.FLOAT2, positions))
        elif hasattr(mesh_to_return, "insertAttribute"):
            mesh_to_return.insertAttribute(Attribute("UVMap", AttributeType.UV_MAP, AttributeDomain.CORNER,
                                            AttributeDataType.FLOAT2, positions))

        return mesh_to_return


def getUVMap(mesh, uvLayer):
    # uvLayer = self.mesh.uv_layers[name]
    uvMap = Vector2DList(length = len(mesh.loops))
    uvLayer.data.foreach_get("uv", uvMap.asMemoryView())
    return uvMap
